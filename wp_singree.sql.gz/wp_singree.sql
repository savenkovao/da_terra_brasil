-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Апр 22 2017 г., 19:41
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `wp_singree`
--

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreecommentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_singreecommentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreecomments`
--

CREATE TABLE IF NOT EXISTS `wp_singreecomments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `wp_singreecomments`
--

INSERT INTO `wp_singreecomments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Автор комментария', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2017-04-16 22:06:39', '2017-04-16 19:06:39', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href="https://ru.gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreelinks`
--

CREATE TABLE IF NOT EXISTS `wp_singreelinks` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreeoptions`
--

CREATE TABLE IF NOT EXISTS `wp_singreeoptions` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=274 ;

--
-- Дамп данных таблицы `wp_singreeoptions`
--

INSERT INTO `wp_singreeoptions` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://test2.ru', 'yes'),
(2, 'home', 'http://test2.ru', 'yes'),
(3, 'blogname', 'Da Terra Brasil Foundation', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'admin@admin.ru', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:91:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:27:"Event adder/Event-Adder.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:5:{i:0;s:73:"Z:\\home\\test2.ru\\www/wp-content/themes/da_terra_brasil/template-event.php";i:1;s:64:"Z:\\home\\test2.ru\\www/wp-content/themes/da_terra_brasil/style.css";i:2;s:72:"Z:\\home\\test2.ru\\www/wp-content/themes/da_terra_brasil/single-events.php";i:3;s:64:"Z:\\home\\test2.ru\\www/wp-content/themes/da_terra_brasil/index.php";i:4;s:0:"";}', 'no'),
(40, 'template', 'da_terra_brasil', 'yes'),
(41, 'stylesheet', 'da_terra_brasil', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '2', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_singreeuser_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'WPLANG', 'en_GB', 'yes'),
(95, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(101, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'cron', 'a:4:{i:1492888002;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1492888193;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1492903142;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(106, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1492369813;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(117, '_site_transient_timeout_browser_1112e7da2c1e2ca5eb7e4651881e05db', '1492974410', 'no'),
(118, '_site_transient_browser_1112e7da2c1e2ca5eb7e4651881e05db', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"57.0.2987.133";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'no'),
(122, 'can_compress_scripts', '1', 'no'),
(135, 'current_theme', 'da_terra_brasil', 'yes'),
(136, 'theme_mods_da_terra_brasil', 'a:4:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:11:"custom_logo";i:7;s:18:"nav_menu_locations";a:2:{s:7:"primary";i:2;s:9:"secondary";i:3;}}', 'yes'),
(137, 'theme_switched', '', 'yes'),
(141, '_transient_da_terra_brasil_categories', '1', 'yes'),
(142, 'theme_mods_twentyfifteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1492371170;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(145, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(196, 'category_children', 'a:0:{}', 'yes'),
(197, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1492427326', 'no'),
(198, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:"stdClass":100:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";i:4328;}s:4:"post";a:3:{s:4:"name";s:4:"post";s:4:"slug";s:4:"post";s:5:"count";i:2469;}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";i:2344;}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";i:2004;}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";i:1813;}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";i:1572;}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";i:1537;}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";i:1422;}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";i:1321;}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";i:1315;}s:8:"facebook";a:3:{s:4:"name";s:8:"facebook";s:4:"slug";s:8:"facebook";s:5:"count";i:1301;}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";i:1264;}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";i:1248;}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";i:1084;}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";i:1036;}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";i:1024;}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";i:976;}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";i:906;}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";i:809;}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";i:779;}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";i:774;}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";i:758;}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";i:748;}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";i:663;}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";i:651;}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";i:641;}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";i:637;}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";i:635;}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";i:631;}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";i:610;}s:4:"ajax";a:3:{s:4:"name";s:4:"ajax";s:4:"slug";s:4:"ajax";s:5:"count";i:589;}s:6:"slider";a:3:{s:4:"name";s:6:"slider";s:4:"slug";s:6:"slider";s:5:"count";i:586;}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";i:584;}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";i:566;}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";i:565;}s:6:"search";a:3:{s:4:"name";s:6:"search";s:4:"slug";s:6:"search";s:5:"count";i:560;}s:9:"analytics";a:3:{s:4:"name";s:9:"analytics";s:4:"slug";s:9:"analytics";s:5:"count";i:557;}s:10:"e-commerce";a:3:{s:4:"name";s:10:"e-commerce";s:4:"slug";s:10:"e-commerce";s:5:"count";i:551;}s:4:"menu";a:3:{s:4:"name";s:4:"menu";s:4:"slug";s:4:"menu";s:5:"count";i:537;}s:5:"embed";a:3:{s:4:"name";s:5:"embed";s:4:"slug";s:5:"embed";s:5:"count";i:531;}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";i:519;}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";i:516;}s:4:"form";a:3:{s:4:"name";s:4:"form";s:4:"slug";s:4:"form";s:5:"count";i:508;}s:3:"css";a:3:{s:4:"name";s:3:"css";s:4:"slug";s:3:"css";s:5:"count";i:496;}s:5:"share";a:3:{s:4:"name";s:5:"share";s:4:"slug";s:5:"share";s:5:"count";i:489;}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";i:485;}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";i:481;}s:5:"theme";a:3:{s:4:"name";s:5:"theme";s:4:"slug";s:5:"theme";s:5:"count";i:471;}s:6:"custom";a:3:{s:4:"name";s:6:"custom";s:4:"slug";s:6:"custom";s:5:"count";i:460;}s:10:"categories";a:3:{s:4:"name";s:10:"categories";s:4:"slug";s:10:"categories";s:5:"count";i:457;}s:10:"responsive";a:3:{s:4:"name";s:10:"responsive";s:4:"slug";s:10:"responsive";s:5:"count";i:455;}s:9:"dashboard";a:3:{s:4:"name";s:9:"dashboard";s:4:"slug";s:9:"dashboard";s:5:"count";i:452;}s:3:"ads";a:3:{s:4:"name";s:3:"ads";s:4:"slug";s:3:"ads";s:5:"count";i:440;}s:6:"button";a:3:{s:4:"name";s:6:"button";s:4:"slug";s:6:"button";s:5:"count";i:434;}s:4:"tags";a:3:{s:4:"name";s:4:"tags";s:4:"slug";s:4:"tags";s:5:"count";i:428;}s:9:"affiliate";a:3:{s:4:"name";s:9:"affiliate";s:4:"slug";s:9:"affiliate";s:5:"count";i:428;}s:6:"editor";a:3:{s:4:"name";s:6:"editor";s:4:"slug";s:6:"editor";s:5:"count";i:420;}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";i:416;}s:4:"user";a:3:{s:4:"name";s:4:"user";s:4:"slug";s:4:"user";s:5:"count";i:406;}s:9:"slideshow";a:3:{s:4:"name";s:9:"slideshow";s:4:"slug";s:9:"slideshow";s:5:"count";i:399;}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";i:398;}s:6:"mobile";a:3:{s:4:"name";s:6:"mobile";s:4:"slug";s:6:"mobile";s:5:"count";i:396;}s:12:"contact-form";a:3:{s:4:"name";s:12:"contact form";s:4:"slug";s:12:"contact-form";s:5:"count";i:396;}s:7:"contact";a:3:{s:4:"name";s:7:"contact";s:4:"slug";s:7:"contact";s:5:"count";i:392;}s:5:"users";a:3:{s:4:"name";s:5:"users";s:4:"slug";s:5:"users";s:5:"count";i:391;}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";i:389;}s:10:"statistics";a:3:{s:4:"name";s:10:"statistics";s:4:"slug";s:10:"statistics";s:5:"count";i:373;}s:3:"api";a:3:{s:4:"name";s:3:"api";s:4:"slug";s:3:"api";s:5:"count";i:367;}s:10:"navigation";a:3:{s:4:"name";s:10:"navigation";s:4:"slug";s:10:"navigation";s:5:"count";i:359;}s:6:"events";a:3:{s:4:"name";s:6:"events";s:4:"slug";s:6:"events";s:5:"count";i:357;}s:4:"news";a:3:{s:4:"name";s:4:"news";s:4:"slug";s:4:"news";s:5:"count";i:345;}s:12:"social-media";a:3:{s:4:"name";s:12:"social media";s:4:"slug";s:12:"social-media";s:5:"count";i:330;}s:8:"calendar";a:3:{s:4:"name";s:8:"calendar";s:4:"slug";s:8:"calendar";s:5:"count";i:330;}s:7:"plugins";a:3:{s:4:"name";s:7:"plugins";s:4:"slug";s:7:"plugins";s:5:"count";i:327;}s:9:"multisite";a:3:{s:4:"name";s:9:"multisite";s:4:"slug";s:9:"multisite";s:5:"count";i:325;}s:10:"shortcodes";a:3:{s:4:"name";s:10:"shortcodes";s:4:"slug";s:10:"shortcodes";s:5:"count";i:319;}s:4:"meta";a:3:{s:4:"name";s:4:"meta";s:4:"slug";s:4:"meta";s:5:"count";i:318;}s:4:"code";a:3:{s:4:"name";s:4:"code";s:4:"slug";s:4:"code";s:5:"count";i:317;}s:4:"list";a:3:{s:4:"name";s:4:"list";s:4:"slug";s:4:"list";s:5:"count";i:316;}s:3:"url";a:3:{s:4:"name";s:3:"url";s:4:"slug";s:3:"url";s:5:"count";i:313;}s:10:"newsletter";a:3:{s:4:"name";s:10:"newsletter";s:4:"slug";s:10:"newsletter";s:5:"count";i:305;}s:7:"payment";a:3:{s:4:"name";s:7:"payment";s:4:"slug";s:7:"payment";s:5:"count";i:303;}s:3:"tag";a:3:{s:4:"name";s:3:"tag";s:4:"slug";s:3:"tag";s:5:"count";i:289;}s:6:"simple";a:3:{s:4:"name";s:6:"simple";s:4:"slug";s:6:"simple";s:5:"count";i:289;}s:5:"popup";a:3:{s:4:"name";s:5:"popup";s:4:"slug";s:5:"popup";s:5:"count";i:286;}s:16:"custom-post-type";a:3:{s:4:"name";s:16:"custom post type";s:4:"slug";s:16:"custom-post-type";s:5:"count";i:283;}s:9:"marketing";a:3:{s:4:"name";s:9:"marketing";s:4:"slug";s:9:"marketing";s:5:"count";i:283;}s:4:"chat";a:3:{s:4:"name";s:4:"chat";s:4:"slug";s:4:"chat";s:5:"count";i:278;}s:8:"redirect";a:3:{s:4:"name";s:8:"redirect";s:4:"slug";s:8:"redirect";s:5:"count";i:278;}s:11:"advertising";a:3:{s:4:"name";s:11:"advertising";s:4:"slug";s:11:"advertising";s:5:"count";i:276;}s:6:"author";a:3:{s:4:"name";s:6:"author";s:4:"slug";s:6:"author";s:5:"count";i:275;}s:7:"adsense";a:3:{s:4:"name";s:7:"adsense";s:4:"slug";s:7:"adsense";s:5:"count";i:270;}s:4:"html";a:3:{s:4:"name";s:4:"html";s:4:"slug";s:4:"html";s:5:"count";i:268;}s:5:"forms";a:3:{s:4:"name";s:5:"forms";s:4:"slug";s:5:"forms";s:5:"count";i:265;}s:7:"captcha";a:3:{s:4:"name";s:7:"captcha";s:4:"slug";s:7:"captcha";s:5:"count";i:263;}s:8:"lightbox";a:3:{s:4:"name";s:8:"lightbox";s:4:"slug";s:8:"lightbox";s:5:"count";i:263;}s:14:"administration";a:3:{s:4:"name";s:14:"administration";s:4:"slug";s:14:"administration";s:5:"count";i:261;}s:12:"notification";a:3:{s:4:"name";s:12:"notification";s:4:"slug";s:12:"notification";s:5:"count";i:260;}s:7:"tinymce";a:3:{s:4:"name";s:7:"tinyMCE";s:4:"slug";s:7:"tinymce";s:5:"count";i:260;}s:15:"payment-gateway";a:3:{s:4:"name";s:15:"payment gateway";s:4:"slug";s:15:"payment-gateway";s:5:"count";i:260;}}', 'no'),
(205, 'wpcf7', 'a:2:{s:7:"version";s:3:"4.7";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1492427405;s:7:"version";s:3:"4.7";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(206, 'recently_activated', 'a:1:{s:31:"Movie-Reviews/Movie-Reviews.php";i:1492427725;}', 'yes'),
(222, '_transient_timeout_dash_f69de0bbfe7eaa113146875f40c02000', '1492474659', 'no'),
(223, '_transient_dash_f69de0bbfe7eaa113146875f40c02000', '<div class="rss-widget"><ul><li><a class=''rsswidget'' href=''https://wordpress.org/news/2017/03/wordpress-4-7-3-security-and-maintenance-release/''>WordPress 4.7.3 Security and Maintenance Release</a> <span class="rss-date">06.03.2017</span><div class="rssSummary">WordPress 4.7.3 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.7.2 and earlier are affected by six security issues: Cross-site scripting (XSS) via media file metadata.  Reported by Chris Andrè Dale, Yorick Koster, and Simon P. Briggs. Control characters can trick redirect [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=''rsswidget'' href=''https://wptavern.com/yoast-office-hosts-bring-your-parents-to-work-day''>WPTavern: Yoast Office Hosts “Bring Your Parents to Work Day”</a></li><li><a class=''rsswidget'' href=''https://wptavern.com/free-react-fundamentals-course-updated-for-react-v15-5''>WPTavern: Free React Fundamentals Course Updated for React v15.5</a></li><li><a class=''rsswidget'' href=''https://wptavern.com/customizer-team-proposes-image-widget-for-wordpress-4-8''>WPTavern: Customizer Team Proposes Image Widget for WordPress 4.8</a></li></ul></div><div class="rss-widget"><ul><li class="dashboard-news-plugin"><span>Популярный плагин:</span> Limit Login Attempts&nbsp;<a href="plugin-install.php?tab=plugin-information&amp;plugin=limit-login-attempts&amp;_wpnonce=7e014cb7e9&amp;TB_iframe=true&amp;width=600&amp;height=800" class="thickbox open-plugin-details-modal" aria-label="Установить Limit Login Attempts">(Установить)</a></li></ul></div>', 'no'),
(226, '_site_transient_timeout_available_translations', '1492447953', 'no');
INSERT INTO `wp_singreeoptions` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(227, '_site_transient_available_translations', 'a:108:{s:2:"af";a:8:{s:8:"language";s:2:"af";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-27 04:32:49";s:12:"english_name";s:9:"Afrikaans";s:11:"native_name";s:9:"Afrikaans";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/af.zip";s:3:"iso";a:2:{i:1;s:2:"af";i:2;s:3:"afr";}s:7:"strings";a:1:{s:8:"continue";s:10:"Gaan voort";}}s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:49:08";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:3:"ary";a:8:{s:8:"language";s:3:"ary";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:42:35";s:12:"english_name";s:15:"Moroccan Arabic";s:11:"native_name";s:31:"العربية المغربية";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.3/ary.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:3;s:3:"ary";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"as";a:8:{s:8:"language";s:2:"as";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-22 18:59:07";s:12:"english_name";s:8:"Assamese";s:11:"native_name";s:21:"অসমীয়া";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/as.zip";s:3:"iso";a:3:{i:1;s:2:"as";i:2;s:3:"asm";i:3;s:3:"asm";}s:7:"strings";a:1:{s:8:"continue";s:0:"";}}s:3:"azb";a:8:{s:8:"language";s:3:"azb";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-12 20:34:31";s:12:"english_name";s:17:"South Azerbaijani";s:11:"native_name";s:29:"گؤنئی آذربایجان";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:3;s:3:"azb";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-06 00:09:27";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:3:"bel";a:8:{s:8:"language";s:3:"bel";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-23 04:36:52";s:12:"english_name";s:10:"Belarusian";s:11:"native_name";s:29:"Беларуская мова";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.3/bel.zip";s:3:"iso";a:2:{i:1;s:2:"be";i:2;s:3:"bel";}s:7:"strings";a:1:{s:8:"continue";s:20:"Працягнуць";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-06 09:18:57";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:12:"Напред";}}s:5:"bn_BD";a:8:{s:8:"language";s:5:"bn_BD";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-04 16:58:43";s:12:"english_name";s:7:"Bengali";s:11:"native_name";s:15:"বাংলা";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/bn_BD.zip";s:3:"iso";a:1:{i:1;s:2:"bn";}s:7:"strings";a:1:{s:8:"continue";s:23:"এগিয়ে চল.";}}s:2:"bo";a:8:{s:8:"language";s:2:"bo";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-05 09:44:12";s:12:"english_name";s:7:"Tibetan";s:11:"native_name";s:21:"བོད་ཡིག";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/bo.zip";s:3:"iso";a:2:{i:1;s:2:"bo";i:2;s:3:"tib";}s:7:"strings";a:1:{s:8:"continue";s:24:"མུ་མཐུད།";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-04 20:20:28";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-05 11:34:47";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:3:"ceb";a:8:{s:8:"language";s:3:"ceb";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-02 17:25:51";s:12:"english_name";s:7:"Cebuano";s:11:"native_name";s:7:"Cebuano";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip";s:3:"iso";a:2:{i:2;s:3:"ceb";i:3;s:3:"ceb";}s:7:"strings";a:1:{s:8:"continue";s:7:"Padayun";}}s:5:"cs_CZ";a:8:{s:8:"language";s:5:"cs_CZ";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-12 08:46:26";s:12:"english_name";s:5:"Czech";s:11:"native_name";s:12:"Čeština‎";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/cs_CZ.zip";s:3:"iso";a:2:{i:1;s:2:"cs";i:2;s:3:"ces";}s:7:"strings";a:1:{s:8:"continue";s:11:"Pokračovat";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:49:29";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-05 09:50:06";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:12:"Forts&#230;t";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-18 13:57:42";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:12:"de_DE_formal";a:8:{s:8:"language";s:12:"de_DE_formal";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-18 13:57:53";s:12:"english_name";s:15:"German (Formal)";s:11:"native_name";s:13:"Deutsch (Sie)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.7.3/de_DE_formal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:14:"de_CH_informal";a:8:{s:8:"language";s:14:"de_CH_informal";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:39:59";s:12:"english_name";s:30:"German (Switzerland, Informal)";s:11:"native_name";s:21:"Deutsch (Schweiz, Du)";s:7:"package";s:73:"https://downloads.wordpress.org/translation/core/4.7.3/de_CH_informal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:40:03";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:3:"dzo";a:8:{s:8:"language";s:3:"dzo";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-06-29 08:59:03";s:12:"english_name";s:8:"Dzongkha";s:11:"native_name";s:18:"རྫོང་ཁ";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip";s:3:"iso";a:2:{i:1;s:2:"dz";i:2;s:3:"dzo";}s:7:"strings";a:1:{s:8:"continue";s:0:"";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-30 00:08:09";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-28 03:10:25";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:49:34";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-27 00:40:28";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_NZ";a:8:{s:8:"language";s:5:"en_NZ";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:54:30";s:12:"english_name";s:21:"English (New Zealand)";s:11:"native_name";s:21:"English (New Zealand)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/en_NZ.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_ZA";a:8:{s:8:"language";s:5:"en_ZA";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:53:43";s:12:"english_name";s:22:"English (South Africa)";s:11:"native_name";s:22:"English (South Africa)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/en_ZA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:47:07";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_VE";a:8:{s:8:"language";s:5:"es_VE";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:53:56";s:12:"english_name";s:19:"Spanish (Venezuela)";s:11:"native_name";s:21:"Español de Venezuela";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/es_VE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-15 12:53:17";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/es_ES.zip";s:3:"iso";a:1:{i:1;s:2:"es";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_GT";a:8:{s:8:"language";s:5:"es_GT";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:54:37";s:12:"english_name";s:19:"Spanish (Guatemala)";s:11:"native_name";s:21:"Español de Guatemala";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/es_GT.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:42:28";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/es_MX.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-09 09:36:22";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-28 20:09:49";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_AR";a:8:{s:8:"language";s:5:"es_AR";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:41:31";s:12:"english_name";s:19:"Spanish (Argentina)";s:11:"native_name";s:21:"Español de Argentina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/es_AR.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CO";a:8:{s:8:"language";s:5:"es_CO";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:54:37";s:12:"english_name";s:18:"Spanish (Colombia)";s:11:"native_name";s:20:"Español de Colombia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/es_CO.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"et";a:8:{s:8:"language";s:2:"et";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-27 16:37:11";s:12:"english_name";s:8:"Estonian";s:11:"native_name";s:5:"Eesti";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/et.zip";s:3:"iso";a:2:{i:1;s:2:"et";i:2;s:3:"est";}s:7:"strings";a:1:{s:8:"continue";s:6:"Jätka";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:54:33";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-02-02 15:21:03";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:42:25";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-18 16:05:09";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_CA";a:8:{s:8:"language";s:5:"fr_CA";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-02-03 21:08:25";s:12:"english_name";s:15:"French (Canada)";s:11:"native_name";s:19:"Français du Canada";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/fr_CA.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_BE";a:8:{s:8:"language";s:5:"fr_BE";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:40:32";s:12:"english_name";s:16:"French (Belgium)";s:11:"native_name";s:21:"Français de Belgique";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/fr_BE.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-08-23 17:41:37";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:40:27";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"gu";a:8:{s:8:"language";s:2:"gu";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-05 06:59:58";s:12:"english_name";s:8:"Gujarati";s:11:"native_name";s:21:"ગુજરાતી";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/gu.zip";s:3:"iso";a:2:{i:1;s:2:"gu";i:2;s:3:"guj";}s:7:"strings";a:1:{s:8:"continue";s:31:"ચાલુ રાખવું";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-05 00:59:09";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip";s:3:"iso";a:1:{i:3;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-29 21:21:10";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:8:"המשך";}}s:5:"hi_IN";a:8:{s:8:"language";s:5:"hi_IN";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-03 12:18:25";s:12:"english_name";s:5:"Hindi";s:11:"native_name";s:18:"हिन्दी";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/hi_IN.zip";s:3:"iso";a:2:{i:1;s:2:"hi";i:2;s:3:"hin";}s:7:"strings";a:1:{s:8:"continue";s:12:"जारी";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-28 13:34:22";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:48:39";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:10:"Folytatás";}}s:2:"hy";a:8:{s:8:"language";s:2:"hy";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-03 16:21:10";s:12:"english_name";s:8:"Armenian";s:11:"native_name";s:14:"Հայերեն";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip";s:3:"iso";a:2:{i:1;s:2:"hy";i:2;s:3:"hye";}s:7:"strings";a:1:{s:8:"continue";s:20:"Շարունակել";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-12 07:41:54";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-13 13:55:54";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-08 04:57:54";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-29 14:23:06";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:9:"続ける";}}s:5:"ka_GE";a:8:{s:8:"language";s:5:"ka_GE";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-05 06:17:00";s:12:"english_name";s:8:"Georgian";s:11:"native_name";s:21:"ქართული";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/ka_GE.zip";s:3:"iso";a:2:{i:1;s:2:"ka";i:2;s:3:"kat";}s:7:"strings";a:1:{s:8:"continue";s:30:"გაგრძელება";}}s:3:"kab";a:8:{s:8:"language";s:3:"kab";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:39:13";s:12:"english_name";s:6:"Kabyle";s:11:"native_name";s:9:"Taqbaylit";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/kab.zip";s:3:"iso";a:2:{i:2;s:3:"kab";i:3;s:3:"kab";}s:7:"strings";a:1:{s:8:"continue";s:6:"Kemmel";}}s:2:"km";a:8:{s:8:"language";s:2:"km";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-07 02:07:59";s:12:"english_name";s:5:"Khmer";s:11:"native_name";s:27:"ភាសាខ្មែរ";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/km.zip";s:3:"iso";a:2:{i:1;s:2:"km";i:2;s:3:"khm";}s:7:"strings";a:1:{s:8:"continue";s:12:"បន្ត";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-04 05:43:51";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:3:"ckb";a:8:{s:8:"language";s:3:"ckb";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:48:25";s:12:"english_name";s:16:"Kurdish (Sorani)";s:11:"native_name";s:13:"كوردی‎";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip";s:3:"iso";a:2:{i:1;s:2:"ku";i:3;s:3:"ckb";}s:7:"strings";a:1:{s:8:"continue";s:30:"به‌رده‌وام به‌";}}s:2:"lo";a:8:{s:8:"language";s:2:"lo";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-12 09:59:23";s:12:"english_name";s:3:"Lao";s:11:"native_name";s:21:"ພາສາລາວ";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip";s:3:"iso";a:2:{i:1;s:2:"lo";i:2;s:3:"lao";}s:7:"strings";a:1:{s:8:"continue";s:18:"ຕໍ່​ໄປ";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-30 09:46:13";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:2:"lv";a:8:{s:8:"language";s:2:"lv";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-17 20:40:40";s:12:"english_name";s:7:"Latvian";s:11:"native_name";s:16:"Latviešu valoda";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/lv.zip";s:3:"iso";a:2:{i:1;s:2:"lv";i:2;s:3:"lav";}s:7:"strings";a:1:{s:8:"continue";s:9:"Turpināt";}}s:5:"mk_MK";a:8:{s:8:"language";s:5:"mk_MK";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:54:41";s:12:"english_name";s:10:"Macedonian";s:11:"native_name";s:31:"Македонски јазик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/mk_MK.zip";s:3:"iso";a:2:{i:1;s:2:"mk";i:2;s:3:"mkd";}s:7:"strings";a:1:{s:8:"continue";s:16:"Продолжи";}}s:5:"ml_IN";a:8:{s:8:"language";s:5:"ml_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-27 03:43:32";s:12:"english_name";s:9:"Malayalam";s:11:"native_name";s:18:"മലയാളം";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip";s:3:"iso";a:2:{i:1;s:2:"ml";i:2;s:3:"mal";}s:7:"strings";a:1:{s:8:"continue";s:18:"തുടരുക";}}s:2:"mn";a:8:{s:8:"language";s:2:"mn";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-12 07:29:35";s:12:"english_name";s:9:"Mongolian";s:11:"native_name";s:12:"Монгол";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip";s:3:"iso";a:2:{i:1;s:2:"mn";i:2;s:3:"mon";}s:7:"strings";a:1:{s:8:"continue";s:24:"Үргэлжлүүлэх";}}s:2:"mr";a:8:{s:8:"language";s:2:"mr";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-24 06:52:11";s:12:"english_name";s:7:"Marathi";s:11:"native_name";s:15:"मराठी";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/mr.zip";s:3:"iso";a:2:{i:1;s:2:"mr";i:2;s:3:"mar";}s:7:"strings";a:1:{s:8:"continue";s:25:"सुरु ठेवा";}}s:5:"ms_MY";a:8:{s:8:"language";s:5:"ms_MY";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-05 09:45:10";s:12:"english_name";s:5:"Malay";s:11:"native_name";s:13:"Bahasa Melayu";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/ms_MY.zip";s:3:"iso";a:2:{i:1;s:2:"ms";i:2;s:3:"msa";}s:7:"strings";a:1:{s:8:"continue";s:8:"Teruskan";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:6:"4.1.16";s:7:"updated";s:19:"2015-03-26 15:57:42";s:12:"english_name";s:17:"Myanmar (Burmese)";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.1.16/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ဆောင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:42:31";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"ne_NP";a:8:{s:8:"language";s:5:"ne_NP";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:48:31";s:12:"english_name";s:6:"Nepali";s:11:"native_name";s:18:"नेपाली";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ne_NP.zip";s:3:"iso";a:2:{i:1;s:2:"ne";i:2;s:3:"nep";}s:7:"strings";a:1:{s:8:"continue";s:43:"जारी राख्नुहोस्";}}s:5:"nl_BE";a:8:{s:8:"language";s:5:"nl_BE";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-21 11:39:51";s:12:"english_name";s:15:"Dutch (Belgium)";s:11:"native_name";s:20:"Nederlands (België)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/nl_BE.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-03 14:07:21";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:12:"nl_NL_formal";a:8:{s:8:"language";s:12:"nl_NL_formal";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-02-16 13:24:21";s:12:"english_name";s:14:"Dutch (Formal)";s:11:"native_name";s:20:"Nederlands (Formeel)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.7.3/nl_NL_formal.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nn_NO";a:8:{s:8:"language";s:5:"nn_NO";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:40:57";s:12:"english_name";s:19:"Norwegian (Nynorsk)";s:11:"native_name";s:13:"Norsk nynorsk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/nn_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nn";i:2;s:3:"nno";}s:7:"strings";a:1:{s:8:"continue";s:9:"Hald fram";}}s:3:"oci";a:8:{s:8:"language";s:3:"oci";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-02 13:47:38";s:12:"english_name";s:7:"Occitan";s:11:"native_name";s:7:"Occitan";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/oci.zip";s:3:"iso";a:2:{i:1;s:2:"oc";i:2;s:3:"oci";}s:7:"strings";a:1:{s:8:"continue";s:9:"Contunhar";}}s:5:"pa_IN";a:8:{s:8:"language";s:5:"pa_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-16 05:19:43";s:12:"english_name";s:7:"Punjabi";s:11:"native_name";s:18:"ਪੰਜਾਬੀ";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip";s:3:"iso";a:2:{i:1;s:2:"pa";i:2;s:3:"pan";}s:7:"strings";a:1:{s:8:"continue";s:25:"ਜਾਰੀ ਰੱਖੋ";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-07 09:27:09";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:6:"4.1.16";s:7:"updated";s:19:"2015-03-29 22:19:48";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1.16/ps.zip";s:3:"iso";a:2:{i:1;s:2:"ps";i:2;s:3:"pus";}s:7:"strings";a:1:{s:8:"continue";s:19:"دوام ورکړه";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-16 03:50:08";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-07 00:19:52";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"rhg";a:8:{s:8:"language";s:3:"rhg";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-16 13:03:18";s:12:"english_name";s:8:"Rohingya";s:11:"native_name";s:8:"Ruáinga";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip";s:3:"iso";a:1:{i:3;s:3:"rhg";}s:7:"strings";a:1:{s:8:"continue";s:0:"";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-15 14:53:36";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-13 19:43:03";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:3:"sah";a:8:{s:8:"language";s:3:"sah";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-21 02:06:41";s:12:"english_name";s:5:"Sakha";s:11:"native_name";s:14:"Сахалыы";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip";s:3:"iso";a:2:{i:2;s:3:"sah";i:3;s:3:"sah";}s:7:"strings";a:1:{s:8:"continue";s:12:"Салҕаа";}}s:5:"si_LK";a:8:{s:8:"language";s:5:"si_LK";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-12 06:00:52";s:12:"english_name";s:7:"Sinhala";s:11:"native_name";s:15:"සිංහල";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip";s:3:"iso";a:2:{i:1;s:2:"si";i:2;s:3:"sin";}s:7:"strings";a:1:{s:8:"continue";s:44:"දිගටම කරගෙන යන්න";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-24 12:22:25";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-02-08 17:57:45";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:8:"Nadaljuj";}}s:2:"sq";a:8:{s:8:"language";s:2:"sq";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-29 18:17:50";s:12:"english_name";s:8:"Albanian";s:11:"native_name";s:5:"Shqip";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/sq.zip";s:3:"iso";a:2:{i:1;s:2:"sq";i:2;s:3:"sqi";}s:7:"strings";a:1:{s:8:"continue";s:6:"Vazhdo";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:41:03";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-03 00:34:10";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:3:"szl";a:8:{s:8:"language";s:3:"szl";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-24 19:58:14";s:12:"english_name";s:8:"Silesian";s:11:"native_name";s:17:"Ślōnskŏ gŏdka";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip";s:3:"iso";a:1:{i:3;s:3:"szl";}s:7:"strings";a:1:{s:8:"continue";s:13:"Kōntynuować";}}s:5:"ta_IN";a:8:{s:8:"language";s:5:"ta_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-27 03:22:47";s:12:"english_name";s:5:"Tamil";s:11:"native_name";s:15:"தமிழ்";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip";s:3:"iso";a:2:{i:1;s:2:"ta";i:2;s:3:"tam";}s:7:"strings";a:1:{s:8:"continue";s:24:"தொடரவும்";}}s:2:"te";a:8:{s:8:"language";s:2:"te";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:47:39";s:12:"english_name";s:6:"Telugu";s:11:"native_name";s:18:"తెలుగు";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/te.zip";s:3:"iso";a:2:{i:1;s:2:"te";i:2;s:3:"tel";}s:7:"strings";a:1:{s:8:"continue";s:30:"కొనసాగించు";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:48:43";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:2:"tl";a:8:{s:8:"language";s:2:"tl";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-30 02:38:08";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip";s:3:"iso";a:2:{i:1;s:2:"tl";i:2;s:3:"tgl";}s:7:"strings";a:1:{s:8:"continue";s:10:"Magpatuloy";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-15 09:03:35";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"tt_RU";a:8:{s:8:"language";s:5:"tt_RU";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-20 20:20:50";s:12:"english_name";s:5:"Tatar";s:11:"native_name";s:19:"Татар теле";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip";s:3:"iso";a:2:{i:1;s:2:"tt";i:2;s:3:"tat";}s:7:"strings";a:1:{s:8:"continue";s:17:"дәвам итү";}}s:3:"tah";a:8:{s:8:"language";s:3:"tah";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-06 18:39:39";s:12:"english_name";s:8:"Tahitian";s:11:"native_name";s:10:"Reo Tahiti";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip";s:3:"iso";a:3:{i:1;s:2:"ty";i:2;s:3:"tah";i:3;s:3:"tah";}s:7:"strings";a:1:{s:8:"continue";s:0:"";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-05 09:23:39";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:9:"Uyƣurqə";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:2:"uk";a:8:{s:8:"language";s:2:"uk";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-28 21:21:58";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/uk.zip";s:3:"iso";a:2:{i:1;s:2:"uk";i:2;s:3:"ukr";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продовжити";}}s:2:"ur";a:8:{s:8:"language";s:2:"ur";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-27 07:08:07";s:12:"english_name";s:4:"Urdu";s:11:"native_name";s:8:"اردو";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/ur.zip";s:3:"iso";a:2:{i:1;s:2:"ur";i:2;s:3:"urd";}s:7:"strings";a:1:{s:8:"continue";s:19:"جاری رکھیں";}}s:5:"uz_UZ";a:8:{s:8:"language";s:5:"uz_UZ";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-04 05:03:16";s:12:"english_name";s:5:"Uzbek";s:11:"native_name";s:11:"O‘zbekcha";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/uz_UZ.zip";s:3:"iso";a:2:{i:1;s:2:"uz";i:2;s:3:"uzb";}s:7:"strings";a:1:{s:8:"continue";s:11:"Davom etish";}}s:2:"vi";a:8:{s:8:"language";s:2:"vi";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-10 15:33:37";s:12:"english_name";s:10:"Vietnamese";s:11:"native_name";s:14:"Tiếng Việt";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.3/vi.zip";s:3:"iso";a:2:{i:1;s:2:"vi";i:2;s:3:"vie";}s:7:"strings";a:1:{s:8:"continue";s:12:"Tiếp tục";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-01-26 15:54:45";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-04-11 04:43:15";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}s:5:"zh_HK";a:8:{s:8:"language";s:5:"zh_HK";s:7:"version";s:5:"4.7.3";s:7:"updated";s:19:"2017-03-28 12:03:30";s:12:"english_name";s:19:"Chinese (Hong Kong)";s:11:"native_name";s:16:"香港中文版	";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.3/zh_HK.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}}', 'no'),
(251, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1492915759', 'no'),
(252, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1492915759', 'no'),
(253, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1492872559', 'no'),
(254, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1492915761', 'no'),
(255, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1492915761', 'no'),
(256, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1492872561', 'no'),
(257, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1492915765', 'no'),
(258, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1492915766', 'no'),
(259, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1492872566', 'no'),
(260, '_transient_timeout_plugin_slugs', '1492958966', 'no'),
(261, '_transient_plugin_slugs', 'a:4:{i:0;s:19:"akismet/akismet.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:27:"Event adder/Event-Adder.php";i:3;s:9:"hello.php";}', 'no'),
(262, '_transient_timeout_dash_5f25301ca0145abac6dfc3a0899dc43b', '1492915766', 'no'),
(263, '_transient_dash_5f25301ca0145abac6dfc3a0899dc43b', '<div class="rss-widget"><ul><li><a class=''rsswidget'' href=''https://wordpress.org/news/2017/04/wordpress-4-7-4/''>WordPress 4.7.4 Maintenance Release</a> <span class="rss-date">20.04.2017</span><div class="rssSummary">After almost sixty million downloads of WordPress 4.7, we are pleased to announce the immediate availability of WordPress 4.7.4, a maintenance release. This release contains 47 bug fixes and enhancements, chief among them an incompatibility between the upcoming Chrome version and the visual editor, inconsistencies in media handling, and further improvements to the REST API.</div></li></ul></div><div class="rss-widget"><ul><li><a class=''rsswidget'' href=''https://ma.tt/2017/04/songs-for-my-father/''>Matt: Songs for My Father</a></li><li><a class=''rsswidget'' href=''https://wptavern.com/embed-mastodon-statuses-in-wordpress''>WPTavern: Embed Mastodon Statuses in WordPress</a></li><li><a class=''rsswidget'' href=''https://wptavern.com/headway-themes-appears-to-be-dying-a-slow-death''>WPTavern: Headway Themes Appears to be Dying a Slow Death</a></li></ul></div><div class="rss-widget"><ul><li class="dashboard-news-plugin"><span>Popular Plugin:</span> Limit Login Attempts&nbsp;<a href="plugin-install.php?tab=plugin-information&amp;plugin=limit-login-attempts&amp;_wpnonce=089496d296&amp;TB_iframe=true&amp;width=600&amp;height=800" class="thickbox open-plugin-details-modal" aria-label="Install Limit Login Attempts">(Install)</a></li></ul></div>', 'no'),
(265, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:65:"https://downloads.wordpress.org/release/en_GB/wordpress-4.7.4.zip";s:6:"locale";s:5:"en_GB";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:65:"https://downloads.wordpress.org/release/en_GB/wordpress-4.7.4.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.7.4";s:7:"version";s:5:"4.7.4";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1492872578;s:15:"version_checked";s:5:"4.7.4";s:12:"translations";a:0:{}}', 'no'),
(266, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1492872585;s:7:"checked";a:1:{s:15:"da_terra_brasil";s:5:"1.0.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'no'),
(267, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1492872583;s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:3:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:3:"3.3";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:54:"https://downloads.wordpress.org/plugin/akismet.3.3.zip";}s:36:"contact-form-7/wp-contact-form-7.php";O:8:"stdClass":6:{s:2:"id";s:3:"790";s:4:"slug";s:14:"contact-form-7";s:6:"plugin";s:36:"contact-form-7/wp-contact-form-7.php";s:11:"new_version";s:3:"4.7";s:3:"url";s:45:"https://wordpress.org/plugins/contact-form-7/";s:7:"package";s:61:"https://downloads.wordpress.org/plugin/contact-form-7.4.7.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}}}', 'no'),
(268, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:14:"admin@admin.ru";s:7:"version";s:5:"4.7.4";s:9:"timestamp";i:1492872581;}', 'no'),
(269, '_site_transient_timeout_popular_importers_c8249e2d9dcdcd9e8d282b415b9a0fff', '1493051519', 'no'),
(270, '_site_transient_popular_importers_c8249e2d9dcdcd9e8d282b415b9a0fff', 'a:2:{s:9:"importers";a:8:{s:7:"blogger";a:4:{s:4:"name";s:7:"Blogger";s:11:"description";s:54:"Import posts, comments, and users from a Blogger blog.";s:11:"plugin-slug";s:16:"blogger-importer";s:11:"importer-id";s:7:"blogger";}s:9:"wpcat2tag";a:4:{s:4:"name";s:29:"Categories and Tags Converter";s:11:"description";s:71:"Convert existing categories to tags or tags to categories, selectively.";s:11:"plugin-slug";s:18:"wpcat2tag-importer";s:11:"importer-id";s:10:"wp-cat2tag";}s:11:"livejournal";a:4:{s:4:"name";s:11:"LiveJournal";s:11:"description";s:46:"Import posts from LiveJournal using their API.";s:11:"plugin-slug";s:20:"livejournal-importer";s:11:"importer-id";s:11:"livejournal";}s:11:"movabletype";a:4:{s:4:"name";s:24:"Movable Type and TypePad";s:11:"description";s:62:"Import posts and comments from a Movable Type or TypePad blog.";s:11:"plugin-slug";s:20:"movabletype-importer";s:11:"importer-id";s:2:"mt";}s:4:"opml";a:4:{s:4:"name";s:8:"Blogroll";s:11:"description";s:28:"Import links in OPML format.";s:11:"plugin-slug";s:13:"opml-importer";s:11:"importer-id";s:4:"opml";}s:3:"rss";a:4:{s:4:"name";s:3:"RSS";s:11:"description";s:30:"Import posts from an RSS feed.";s:11:"plugin-slug";s:12:"rss-importer";s:11:"importer-id";s:3:"rss";}s:6:"tumblr";a:4:{s:4:"name";s:6:"Tumblr";s:11:"description";s:53:"Import posts &amp; media from Tumblr using their API.";s:11:"plugin-slug";s:15:"tumblr-importer";s:11:"importer-id";s:6:"tumblr";}s:9:"wordpress";a:4:{s:4:"name";s:9:"WordPress";s:11:"description";s:96:"Import posts, pages, comments, custom fields, categories, and tags from a WordPress export file.";s:11:"plugin-slug";s:18:"wordpress-importer";s:11:"importer-id";s:9:"wordpress";}}s:10:"translated";b:0;}', 'no'),
(272, '_site_transient_timeout_theme_roots', '1492880540', 'no'),
(273, '_site_transient_theme_roots', 'a:1:{s:15:"da_terra_brasil";s:7:"/themes";}', 'no');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreepostmeta`
--

CREATE TABLE IF NOT EXISTS `wp_singreepostmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=405 ;

--
-- Дамп данных таблицы `wp_singreepostmeta`
--

INSERT INTO `wp_singreepostmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_wp_trash_meta_status', 'publish'),
(3, 4, '_wp_trash_meta_time', '1492378685'),
(4, 5, '_wp_trash_meta_status', 'publish'),
(5, 5, '_wp_trash_meta_time', '1492378694'),
(6, 6, '_wp_attached_file', '2017/04/logo.png'),
(7, 6, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:129;s:6:"height";i:85;s:4:"file";s:16:"2017/04/logo.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(8, 6, '_wp_attachment_image_alt', 'logo'),
(9, 7, '_wp_attached_file', '2017/04/cropped-logo.png'),
(10, 7, '_wp_attachment_context', 'custom-logo'),
(11, 7, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:129;s:6:"height";i:85;s:4:"file";s:24:"2017/04/cropped-logo.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(12, 8, '_wp_trash_meta_status', 'publish'),
(13, 8, '_wp_trash_meta_time', '1492379256'),
(14, 1, '_edit_lock', '1492380010:1'),
(33, 11, '_menu_item_type', 'custom'),
(34, 11, '_menu_item_menu_item_parent', '0'),
(35, 11, '_menu_item_object_id', '11'),
(36, 11, '_menu_item_object', 'custom'),
(37, 11, '_menu_item_target', ''),
(38, 11, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(39, 11, '_menu_item_xfn', ''),
(40, 11, '_menu_item_url', 'index.php'),
(42, 12, '_menu_item_type', 'custom'),
(43, 12, '_menu_item_menu_item_parent', '0'),
(44, 12, '_menu_item_object_id', '12'),
(45, 12, '_menu_item_object', 'custom'),
(46, 12, '_menu_item_target', ''),
(47, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(48, 12, '_menu_item_xfn', ''),
(49, 12, '_menu_item_url', '#about-us'),
(51, 13, '_menu_item_type', 'custom'),
(52, 13, '_menu_item_menu_item_parent', '0'),
(53, 13, '_menu_item_object_id', '13'),
(54, 13, '_menu_item_object', 'custom'),
(55, 13, '_menu_item_target', ''),
(56, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(57, 13, '_menu_item_xfn', ''),
(58, 13, '_menu_item_url', '#our-work'),
(60, 14, '_menu_item_type', 'custom'),
(61, 14, '_menu_item_menu_item_parent', '0'),
(62, 14, '_menu_item_object_id', '14'),
(63, 14, '_menu_item_object', 'custom'),
(64, 14, '_menu_item_target', ''),
(65, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(66, 14, '_menu_item_xfn', ''),
(67, 14, '_menu_item_url', '#'),
(69, 15, '_menu_item_type', 'custom'),
(70, 15, '_menu_item_menu_item_parent', '0'),
(71, 15, '_menu_item_object_id', '15'),
(72, 15, '_menu_item_object', 'custom'),
(73, 15, '_menu_item_target', ''),
(74, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(75, 15, '_menu_item_xfn', ''),
(76, 15, '_menu_item_url', '#contact'),
(78, 16, '_menu_item_type', 'custom'),
(79, 16, '_menu_item_menu_item_parent', '0'),
(80, 16, '_menu_item_object_id', '16'),
(81, 16, '_menu_item_object', 'custom'),
(82, 16, '_menu_item_target', ''),
(83, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(84, 16, '_menu_item_xfn', ''),
(85, 16, '_menu_item_url', '#ways'),
(87, 17, '_menu_item_type', 'custom'),
(88, 17, '_menu_item_menu_item_parent', '0'),
(89, 17, '_menu_item_object_id', '17'),
(90, 17, '_menu_item_object', 'custom'),
(91, 17, '_menu_item_target', ''),
(92, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(93, 17, '_menu_item_xfn', ''),
(94, 17, '_menu_item_url', '#stories'),
(96, 18, '_menu_item_type', 'custom'),
(97, 18, '_menu_item_menu_item_parent', '0'),
(98, 18, '_menu_item_object_id', '18'),
(99, 18, '_menu_item_object', 'custom'),
(100, 18, '_menu_item_target', ''),
(101, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(102, 18, '_menu_item_xfn', ''),
(103, 18, '_menu_item_url', '#'),
(105, 19, '_menu_item_type', 'custom'),
(106, 19, '_menu_item_menu_item_parent', '16'),
(107, 19, '_menu_item_object_id', '19'),
(108, 19, '_menu_item_object', 'custom'),
(109, 19, '_menu_item_target', ''),
(110, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(111, 19, '_menu_item_xfn', ''),
(112, 19, '_menu_item_url', '#'),
(114, 20, '_menu_item_type', 'custom'),
(115, 20, '_menu_item_menu_item_parent', '16'),
(116, 20, '_menu_item_object_id', '20'),
(117, 20, '_menu_item_object', 'custom'),
(118, 20, '_menu_item_target', ''),
(119, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(120, 20, '_menu_item_xfn', ''),
(121, 20, '_menu_item_url', '#'),
(123, 21, '_menu_item_type', 'custom'),
(124, 21, '_menu_item_menu_item_parent', '16'),
(125, 21, '_menu_item_object_id', '21'),
(126, 21, '_menu_item_object', 'custom'),
(127, 21, '_menu_item_target', ''),
(128, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(129, 21, '_menu_item_xfn', ''),
(130, 21, '_menu_item_url', '#'),
(132, 22, '_menu_item_type', 'custom'),
(133, 22, '_menu_item_menu_item_parent', '17'),
(134, 22, '_menu_item_object_id', '22'),
(135, 22, '_menu_item_object', 'custom'),
(136, 22, '_menu_item_target', ''),
(137, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(138, 22, '_menu_item_xfn', ''),
(139, 22, '_menu_item_url', '#'),
(141, 23, '_menu_item_type', 'custom'),
(142, 23, '_menu_item_menu_item_parent', '18'),
(143, 23, '_menu_item_object_id', '23'),
(144, 23, '_menu_item_object', 'custom'),
(145, 23, '_menu_item_target', ''),
(146, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(147, 23, '_menu_item_xfn', ''),
(148, 23, '_menu_item_url', '#'),
(150, 24, '_menu_item_type', 'custom'),
(151, 24, '_menu_item_menu_item_parent', '18'),
(152, 24, '_menu_item_object_id', '24'),
(153, 24, '_menu_item_object', 'custom'),
(154, 24, '_menu_item_target', ''),
(155, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(156, 24, '_menu_item_xfn', ''),
(157, 24, '_menu_item_url', '#'),
(159, 25, '_menu_item_type', 'custom'),
(160, 25, '_menu_item_menu_item_parent', '17'),
(161, 25, '_menu_item_object_id', '25'),
(162, 25, '_menu_item_object', 'custom'),
(163, 25, '_menu_item_target', ''),
(164, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(165, 25, '_menu_item_xfn', ''),
(166, 25, '_menu_item_url', '#'),
(168, 26, '_edit_last', '1'),
(169, 26, '_edit_lock', '1492385616:1'),
(170, 27, '_wp_attached_file', '2017/04/item-2.jpg'),
(171, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:246;s:6:"height";i:251;s:4:"file";s:18:"2017/04/item-2.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"item-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(172, 26, '_thumbnail_id', '27'),
(175, 1, '_wp_trash_meta_status', 'publish'),
(176, 1, '_wp_trash_meta_time', '1492385416'),
(177, 1, '_wp_desired_post_slug', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80'),
(178, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(179, 30, '_edit_last', '1'),
(180, 30, '_edit_lock', '1492385564:1'),
(181, 31, '_wp_attached_file', '2017/04/item-1.jpg'),
(182, 31, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:243;s:6:"height";i:247;s:4:"file";s:18:"2017/04/item-1.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"item-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(183, 31, '_wp_attachment_image_alt', 'item-1'),
(184, 30, '_thumbnail_id', '31'),
(191, 34, '_edit_last', '1'),
(192, 34, '_edit_lock', '1492386085:1'),
(193, 35, '_wp_attached_file', '2017/04/item-2-1.jpg'),
(194, 35, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:460;s:6:"height";i:460;s:4:"file";s:20:"2017/04/item-2-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"item-2-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"item-2-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(195, 35, '_wp_attachment_image_alt', 'item-2'),
(196, 34, '_thumbnail_id', '35'),
(199, 37, '_edit_last', '1'),
(200, 37, '_edit_lock', '1492386858:1'),
(201, 38, '_wp_attached_file', '2017/04/item-3.jpg'),
(202, 38, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:460;s:6:"height";i:460;s:4:"file";s:18:"2017/04/item-3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"item-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"item-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(203, 38, '_wp_attachment_image_alt', 'item-3'),
(204, 37, '_thumbnail_id', '38'),
(207, 40, '_edit_last', '1'),
(208, 40, '_edit_lock', '1492388423:1'),
(209, 27, '_wp_attachment_image_alt', 'item-2'),
(213, 42, '_wp_attached_file', '2017/04/1.jpg'),
(214, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:677;s:6:"height";i:489;s:4:"file";s:13:"2017/04/1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:13:"1-300x217.jpg";s:5:"width";i:300;s:6:"height";i:217;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(215, 42, '_wp_attachment_image_alt', 'photo'),
(218, 40, '_thumbnail_id', '42'),
(225, 44, '_edit_last', '1'),
(226, 44, '_edit_lock', '1492408251:1'),
(231, 47, '_edit_last', '1'),
(232, 47, '_edit_lock', '1492408287:1'),
(235, 49, '_edit_last', '1'),
(236, 49, '_edit_lock', '1492408321:1'),
(239, 51, '_edit_last', '1'),
(240, 51, '_edit_lock', '1492408360:1'),
(243, 53, '_edit_last', '1'),
(244, 53, '_edit_lock', '1492408389:1'),
(247, 55, '_edit_last', '1'),
(248, 55, '_edit_lock', '1492409495:1'),
(251, 55, '_wp_trash_meta_status', 'publish'),
(252, 55, '_wp_trash_meta_time', '1492409643'),
(253, 55, '_wp_desired_post_slug', 'quote-6'),
(254, 57, '_edit_last', '1'),
(255, 57, '_edit_lock', '1492412334:1'),
(262, 61, '_edit_last', '1'),
(263, 61, '_edit_lock', '1492412561:1'),
(264, 62, '_wp_attached_file', '2017/04/photo-1.jpg'),
(265, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:164;s:6:"height";i:189;s:4:"file";s:19:"2017/04/photo-1.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"photo-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(266, 62, '_wp_attachment_image_alt', 'photo-1'),
(267, 61, '_thumbnail_id', '62'),
(270, 64, '_edit_last', '1'),
(271, 64, '_edit_lock', '1492413838:1'),
(274, 66, '_edit_last', '1'),
(275, 66, '_edit_lock', '1492414321:1'),
(278, 68, '_edit_last', '1'),
(279, 68, '_edit_lock', '1492414649:1'),
(280, 69, '_wp_attached_file', '2017/04/item-1-1.jpg'),
(281, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:460;s:6:"height";i:460;s:4:"file";s:20:"2017/04/item-1-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"item-1-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"item-1-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(282, 70, '_wp_attached_file', '2017/04/item-2-2.jpg'),
(283, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:460;s:6:"height";i:460;s:4:"file";s:20:"2017/04/item-2-2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"item-2-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"item-2-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(284, 71, '_wp_attached_file', '2017/04/item-3-1.jpg'),
(285, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:460;s:6:"height";i:460;s:4:"file";s:20:"2017/04/item-3-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"item-3-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"item-3-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(286, 72, '_wp_attached_file', '2017/04/item-4.jpg'),
(287, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:460;s:6:"height";i:460;s:4:"file";s:18:"2017/04/item-4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"item-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"item-4-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(288, 73, '_wp_attached_file', '2017/04/item-5.jpg'),
(289, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:460;s:6:"height";i:460;s:4:"file";s:18:"2017/04/item-5.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"item-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"item-5-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(290, 74, '_wp_attached_file', '2017/04/item-6.jpg'),
(291, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:460;s:6:"height";i:460;s:4:"file";s:18:"2017/04/item-6.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"item-6-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"item-6-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(292, 74, '_wp_attachment_image_alt', 'item-6'),
(293, 68, '_thumbnail_id', '74'),
(296, 76, '_edit_last', '1'),
(297, 76, '_edit_lock', '1492414768:1'),
(298, 76, '_thumbnail_id', '73'),
(301, 79, '_edit_last', '1'),
(302, 79, '_edit_lock', '1492414726:1'),
(303, 72, '_wp_attachment_image_alt', 'item-4'),
(304, 79, '_thumbnail_id', '72'),
(307, 81, '_edit_last', '1'),
(308, 81, '_edit_lock', '1492414778:1'),
(309, 71, '_wp_attachment_image_alt', 'item-3'),
(310, 81, '_thumbnail_id', '71'),
(315, 83, '_edit_last', '1'),
(316, 83, '_edit_lock', '1492414812:1'),
(317, 70, '_wp_attachment_image_alt', 'item-2'),
(318, 83, '_thumbnail_id', '70'),
(321, 69, '_wp_attachment_image_alt', 'item-1'),
(322, 85, '_edit_last', '1'),
(323, 85, '_thumbnail_id', '69'),
(326, 85, '_edit_lock', '1492415106:1'),
(327, 87, '_edit_last', '1'),
(328, 87, '_edit_lock', '1492415620:1'),
(331, 89, '_edit_last', '1'),
(332, 89, '_edit_lock', '1492416295:1'),
(335, 87, '_wp_trash_meta_status', 'publish'),
(336, 87, '_wp_trash_meta_time', '1492416180'),
(337, 87, '_wp_desired_post_slug', 'the-portal-amigo-do-idoso-event-on-behalf-of-the-brasil-on-wheels-campaign-appears-on-the-brazilian-american-chamber-of-commerce-website'),
(338, 91, '_edit_last', '1'),
(341, 91, '_edit_lock', '1492416303:1'),
(348, 95, '_form', '<span class=''contact-form__radio-txt''>Questions about:</span>[radio radio-60 class:asas default:1 "Volunteering" "Inquire about donations" "More information" "Other"]\n[text* text-128 placeholder "Name (required)"] [email email-807 placeholder "E-mail Address (required)"]\n[textarea textarea-718 placeholder "Message"]\n\n[submit "submit"]'),
(349, 95, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:43:"Da Terra Brasil Foundation "[your-subject]"";s:6:"sender";s:32:"[your-name] <wordpress@test2.ru>";s:9:"recipient";s:14:"admin@admin.ru";s:4:"body";s:204:"От: [your-name] <[your-email]>\nТема: [your-subject]\n\nСообщение:\n[your-message]\n\n-- \nЭто сообщение отправлено с сайта Da Terra Brasil Foundation (http://test2.ru)";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(350, 95, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:43:"Da Terra Brasil Foundation "[your-subject]"";s:6:"sender";s:47:"Da Terra Brasil Foundation <wordpress@test2.ru>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:145:"Сообщение:\n[your-message]\n\n-- \nЭто сообщение отправлено с сайта Da Terra Brasil Foundation (http://test2.ru)";s:18:"additional_headers";s:24:"Reply-To: admin@admin.ru";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(351, 95, '_messages', 'a:23:{s:12:"mail_sent_ok";s:92:"Спасибо за Ваше сообщение. Оно успешно отправлено.";s:12:"mail_sent_ng";s:144:"При отправке сообщения произошла ошибка. Пожалуйста, попробуйте ещё раз позже.";s:16:"validation_error";s:180:"Одно или несколько полей содержат ошибочные данные. Пожалуйста, проверьте их и попробуйте ещё раз.";s:4:"spam";s:144:"При отправке сообщения произошла ошибка. Пожалуйста, попробуйте ещё раз позже.";s:12:"accept_terms";s:132:"Вы должны принять условия и положения перед отправкой вашего сообщения.";s:16:"invalid_required";s:60:"Поле обязательно для заполнения.";s:16:"invalid_too_long";s:39:"Поле слишком длинное.";s:17:"invalid_too_short";s:41:"Поле слишком короткое.";s:12:"invalid_date";s:45:"Формат даты некорректен.";s:14:"date_too_early";s:74:"Введённая дата слишком далеко в прошлом.";s:13:"date_too_late";s:74:"Введённая дата слишком далеко в будущем.";s:13:"upload_failed";s:90:"При загрузке файла произошла неизвестная ошибка.";s:24:"upload_file_type_invalid";s:81:"Вам не разрешено загружать файлы этого типа.";s:21:"upload_file_too_large";s:39:"Файл слишком большой.";s:23:"upload_failed_php_error";s:67:"При загрузке файла произошла ошибка.";s:14:"invalid_number";s:47:"Формат числа некорректен.";s:16:"number_too_small";s:68:"Число меньше минимально допустимого.";s:16:"number_too_large";s:70:"Число больше максимально допустимого.";s:23:"quiz_answer_not_correct";s:69:"Неверный ответ на проверочный вопрос.";s:17:"captcha_not_match";s:35:"Код введен неверно.";s:13:"invalid_email";s:62:"Неверно введён электронный адрес.";s:11:"invalid_url";s:53:"Введён некорректный URL адрес.";s:11:"invalid_tel";s:70:"Введён некорректный телефонный номер.";}'),
(352, 95, '_additional_settings', ''),
(353, 95, '_locale', 'ru_RU'),
(355, 93, '_edit_last', '1'),
(356, 93, '_edit_lock', '1492879078:1'),
(363, 95, '_config_errors', 'a:1:{s:23:"mail.additional_headers";a:1:{i:0;a:2:{s:4:"code";i:102;s:4:"args";a:3:{s:7:"message";s:125:"Был использован некорректный синтаксис почтового адреса в поле %name%.";s:6:"params";a:1:{s:4:"name";s:8:"Reply-To";}s:4:"link";s:68:"https://contactform7.com/configuration-errors/invalid-mailbox-syntax";}}}}'),
(364, 2, '_edit_last', '1'),
(365, 2, '_edit_lock', '1492878824:1'),
(366, 98, '_edit_last', '1'),
(367, 98, '_edit_lock', '1492878894:1'),
(368, 100, '_menu_item_type', 'post_type'),
(369, 100, '_menu_item_menu_item_parent', '0'),
(370, 100, '_menu_item_object_id', '98'),
(371, 100, '_menu_item_object', 'page'),
(372, 100, '_menu_item_target', ''),
(373, 100, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(374, 100, '_menu_item_xfn', ''),
(375, 100, '_menu_item_url', ''),
(376, 100, '_menu_item_orphaned', '1492425752'),
(377, 103, '_edit_last', '1'),
(378, 103, '_edit_lock', '1492428520:1'),
(379, 103, '_thumbnail_id', '35'),
(380, 105, '_edit_last', '1'),
(381, 105, '_edit_lock', '1492436355:1'),
(382, 105, '_thumbnail_id', '71'),
(383, 98, '_wp_page_template', 'page-events.php'),
(384, 108, '_edit_last', '1'),
(385, 108, '_edit_lock', '1492435897:1'),
(386, 110, '_edit_last', '1'),
(387, 110, '_edit_lock', '1492873410:1'),
(388, 105, 'event_date', '13.10.2017'),
(389, 105, 'event_period', '12 days'),
(390, 105, 'event_place', 'Odessa'),
(391, 108, 'event_date', '12.12.2016'),
(392, 108, 'event_period', '100 days'),
(393, 108, 'event_place', 'Kherson'),
(394, 108, '_thumbnail_id', '69'),
(395, 110, '_thumbnail_id', '42'),
(396, 110, 'event_date', '17.08.2016'),
(397, 110, 'event_period', '7 days'),
(398, 110, 'event_place', 'Lviv'),
(399, 113, '_edit_last', '1'),
(400, 113, '_edit_lock', '1492878930:1'),
(401, 113, 'event_date', '30.03.2017'),
(402, 113, 'event_period', '3 days'),
(403, 113, 'event_place', 'Niko'),
(404, 113, '_thumbnail_id', '31');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreeposts`
--

CREATE TABLE IF NOT EXISTS `wp_singreeposts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=116 ;

--
-- Дамп данных таблицы `wp_singreeposts`
--

INSERT INTO `wp_singreeposts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-04-16 22:06:39', '2017-04-16 19:06:39', 'Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите её, затем пишите!', 'Привет, мир!', '', 'trash', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80__trashed', '', '', '2017-04-17 02:30:16', '2017-04-16 23:30:16', '', 0, 'http://test2.ru/?p=1', 0, 'post', '', 1),
(2, 1, '2017-04-16 22:06:39', '2017-04-16 19:06:39', '', 'Home page', '', 'publish', 'closed', 'closed', '', 'home-page', '', '', '2017-04-22 19:35:59', '2017-04-22 16:35:59', '', 0, 'http://test2.ru/?page_id=2', 0, 'page', '', 0),
(3, 1, '2017-04-16 22:06:51', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-04-16 22:06:51', '0000-00-00 00:00:00', '', 0, 'http://test2.ru/?p=3', 0, 'post', '', 0),
(4, 1, '2017-04-17 00:38:04', '2017-04-16 21:38:04', '{"blogdescription":{"value":"","type":"option","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '39b4c243-a10f-461c-b213-ee596ed26269', '', '', '2017-04-17 00:38:04', '2017-04-16 21:38:04', '', 0, 'http://test2.ru/2017/04/17/39b4c243-a10f-461c-b213-ee596ed26269/', 0, 'customize_changeset', '', 0),
(5, 1, '2017-04-17 00:38:13', '2017-04-16 21:38:13', '{"blogname":{"value":"Da Terra Brasil Foundation","type":"option","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '2d01e4ce-5866-4f74-bfd6-cd705950b75c', '', '', '2017-04-17 00:38:13', '2017-04-16 21:38:13', '', 0, 'http://test2.ru/2017/04/17/2d01e4ce-5866-4f74-bfd6-cd705950b75c/', 0, 'customize_changeset', '', 0),
(6, 1, '2017-04-17 00:47:18', '2017-04-16 21:47:18', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2017-04-17 00:47:28', '2017-04-16 21:47:28', '', 0, 'http://test2.ru/wp-content/uploads/2017/04/logo.png', 0, 'attachment', 'image/png', 0),
(7, 1, '2017-04-17 00:47:30', '2017-04-16 21:47:30', 'http://test2.ru/wp-content/uploads/2017/04/cropped-logo.png', 'cropped-logo.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-png', '', '', '2017-04-17 00:47:30', '2017-04-16 21:47:30', '', 0, 'http://test2.ru/wp-content/uploads/2017/04/cropped-logo.png', 0, 'attachment', 'image/png', 0),
(8, 1, '2017-04-17 00:47:35', '2017-04-16 21:47:35', '{"da_terra_brasil::custom_logo":{"value":7,"type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '3f928bce-42e8-4ca7-a716-097ae23e5052', '', '', '2017-04-17 00:47:35', '2017-04-16 21:47:35', '', 0, 'http://test2.ru/?p=8', 0, 'customize_changeset', '', 0),
(11, 1, '2017-04-17 01:05:39', '2017-04-16 22:05:39', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-04-17 01:22:22', '2017-04-16 22:22:22', '', 0, 'http://test2.ru/?p=11', 1, 'nav_menu_item', '', 0),
(12, 1, '2017-04-17 01:05:39', '2017-04-16 22:05:39', '', 'About us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2017-04-17 01:22:22', '2017-04-16 22:22:22', '', 0, 'http://test2.ru/?p=12', 2, 'nav_menu_item', '', 0),
(13, 1, '2017-04-17 01:05:39', '2017-04-16 22:05:39', '', 'Our work', '', 'publish', 'closed', 'closed', '', 'our-work', '', '', '2017-04-17 01:22:22', '2017-04-16 22:22:22', '', 0, 'http://test2.ru/?p=13', 3, 'nav_menu_item', '', 0),
(14, 1, '2017-04-17 01:05:40', '2017-04-16 22:05:40', '', 'News & events', '', 'publish', 'closed', 'closed', '', 'news-events', '', '', '2017-04-17 01:22:22', '2017-04-16 22:22:22', '', 0, 'http://test2.ru/?p=14', 4, 'nav_menu_item', '', 0),
(15, 1, '2017-04-17 01:05:40', '2017-04-16 22:05:40', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2017-04-17 01:22:22', '2017-04-16 22:22:22', '', 0, 'http://test2.ru/?p=15', 5, 'nav_menu_item', '', 0),
(16, 1, '2017-04-17 01:27:38', '2017-04-16 22:27:38', '', 'Ways to help', '', 'publish', 'closed', 'closed', '', 'ways-to-help', '', '', '2017-04-17 01:43:04', '2017-04-16 22:43:04', '', 0, 'http://test2.ru/?p=16', 1, 'nav_menu_item', '', 0),
(17, 1, '2017-04-17 01:27:39', '2017-04-16 22:27:39', '', 'Stories', '', 'publish', 'closed', 'closed', '', 'stories', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=17', 5, 'nav_menu_item', '', 0),
(18, 1, '2017-04-17 01:27:40', '2017-04-16 22:27:40', '', 'Support a project', '', 'publish', 'closed', 'closed', '', 'support-a-project', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=18', 8, 'nav_menu_item', '', 0),
(19, 1, '2017-04-17 01:27:38', '2017-04-16 22:27:38', '', 'item 1', '', 'publish', 'closed', 'closed', '', 'item-1', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=19', 2, 'nav_menu_item', '', 0),
(20, 1, '2017-04-17 01:27:39', '2017-04-16 22:27:39', '', 'item 2', '', 'publish', 'closed', 'closed', '', 'item-2', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=20', 3, 'nav_menu_item', '', 0),
(21, 1, '2017-04-17 01:27:39', '2017-04-16 22:27:39', '', 'item 3', '', 'publish', 'closed', 'closed', '', 'item-3', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=21', 4, 'nav_menu_item', '', 0),
(22, 1, '2017-04-17 01:27:39', '2017-04-16 22:27:39', '', 'item 1', '', 'publish', 'closed', 'closed', '', 'item-1-2', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=22', 6, 'nav_menu_item', '', 0),
(23, 1, '2017-04-17 01:27:40', '2017-04-16 22:27:40', '', 'item 1', '', 'publish', 'closed', 'closed', '', 'item-1-3', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=23', 9, 'nav_menu_item', '', 0),
(24, 1, '2017-04-17 01:27:40', '2017-04-16 22:27:40', '', 'item 2', '', 'publish', 'closed', 'closed', '', 'item-2-2', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=24', 10, 'nav_menu_item', '', 0),
(25, 1, '2017-04-17 01:39:54', '2017-04-16 22:39:54', '', 'item 2', '', 'publish', 'closed', 'closed', '', 'item-2-3', '', '', '2017-04-17 01:43:05', '2017-04-16 22:43:05', '', 0, 'http://test2.ru/?p=25', 7, 'nav_menu_item', '', 0),
(26, 1, '2017-04-17 02:20:17', '2017-04-16 23:20:17', 'Casa Maria Maia is a nonprofit organization in Carapicuiba, São Paulo, dedicated to caring for abandoned children with severe disabilities. A multidisciplinary team of volunteers, including neurologists, physical therapists, social workers, entertainers, and caretakers, tend to 20 children and young adults housed in the facility.', 'Making a Difference at Casa Maria Maia…', '', 'publish', 'open', 'open', '', '%d0%bc%d0%be%d1%8f-%d0%bf%d0%b5%d1%80%d0%b2%d0%b0%d1%8f-%d0%b7%d0%b0%d0%bf%d0%b8%d1%81%d1%8c', '', '', '2017-04-17 02:35:01', '2017-04-16 23:35:01', '', 0, 'http://test2.ru/?p=26', 0, 'post', '', 0),
(27, 1, '2017-04-17 02:20:04', '2017-04-16 23:20:04', '', 'item-2', '', 'inherit', 'open', 'closed', '', 'item-2-4', '', '', '2017-04-17 02:57:25', '2017-04-16 23:57:25', '', 26, 'http://test2.ru/wp-content/uploads/2017/04/item-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2017-04-17 02:20:17', '2017-04-16 23:20:17', 'Displays the <a title="Glossary" href="https://codex.wordpress.org/Glossary#URI_and_URL">URL</a> for the <a title="Glossary" href="https://codex.wordpress.org/Glossary#Permalink">permalink</a> to the post currently being processed in <a title="The Loop" href="https://codex.wordpress.org/The_Loop">The Loop</a>. This tag must be within <a title="The Loop" href="https://codex.wordpress.org/The_Loop">The Loop</a>, and is generally used to display the permalink for each post, when the posts are being displayed. Since this template tag is limited to displaying the permalink for the post that is being processed, you cannot use it to display the permalink to an arbitrary post on your weblog.', 'Моя первая запись', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2017-04-17 02:20:17', '2017-04-16 23:20:17', '', 26, 'http://test2.ru/2017/04/17/26-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2017-04-17 02:30:16', '2017-04-16 23:30:16', 'Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите её, затем пишите!', 'Привет, мир!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2017-04-17 02:30:16', '2017-04-16 23:30:16', '', 1, 'http://test2.ru/2017/04/17/1-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2017-04-17 02:33:50', '2017-04-16 23:33:50', 'Jeni Golcalves Arruda always has a smile on her face, despite her disability and financial struggles.  She has many reasons to be happy. She says her husband, Luis, is the reason for her positive atittute, since he is very supportive of her needs.  Jeni has been confined to a wheelchair since losing her leg to diabetes. When we met Jeni, her chair was old and in disrepair, keeping her inside the house most of the days.', 'Meet Jeni Gonçalves Arruda…', '', 'publish', 'open', 'open', '', 'meet-jeni-goncalves-arruda', '', '', '2017-04-17 02:34:04', '2017-04-16 23:34:04', '', 0, 'http://test2.ru/?p=30', 0, 'post', '', 0),
(31, 1, '2017-04-17 02:33:38', '2017-04-16 23:33:38', '', 'item-1', '', 'inherit', 'open', 'closed', '', 'item-1-4', '', '', '2017-04-17 02:33:45', '2017-04-16 23:33:45', '', 30, 'http://test2.ru/wp-content/uploads/2017/04/item-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2017-04-17 02:33:50', '2017-04-16 23:33:50', 'Jeni Golcalves Arruda always has a smile on her face, despite her disability and financial struggles.  She has many reasons to be happy. She says her husband, Luis, is the reason for her positive atittute, since he is very supportive of her needs.  Jeni has been confined to a wheelchair since losing her leg to diabetes. When we met Jeni, her chair was old and in disrepair, keeping her inside the house most of the days.', 'Meet Jeni Gonçalves Arruda…', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2017-04-17 02:33:50', '2017-04-16 23:33:50', '', 30, 'http://test2.ru/2017/04/17/30-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2017-04-17 02:35:01', '2017-04-16 23:35:01', 'Casa Maria Maia is a nonprofit organization in Carapicuiba, São Paulo, dedicated to caring for abandoned children with severe disabilities. A multidisciplinary team of volunteers, including neurologists, physical therapists, social workers, entertainers, and caretakers, tend to 20 children and young adults housed in the facility.', 'Making a Difference at Casa Maria Maia…', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2017-04-17 02:35:01', '2017-04-16 23:35:01', '', 26, 'http://test2.ru/2017/04/17/26-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2017-04-17 02:35:55', '2017-04-16 23:35:55', 'Casa Maria Maia is a nonprofit organization in Carapicuiba, São Paulo, dedicated to caring for abandoned children with severe disabilities. A multidisciplinary team of volunteers, including neurologists, physical therapists, social workers, entertainers, and caretakers, tend to 20 children and young adults housed in the facility.', 'Meet Jeni Gonçalves Arruda…', '', 'publish', 'open', 'open', '', 'meet-jeni-goncalves-arruda-2', '', '', '2017-04-17 02:35:55', '2017-04-16 23:35:55', '', 0, 'http://test2.ru/?p=34', 0, 'post', '', 0),
(35, 1, '2017-04-17 02:35:43', '2017-04-16 23:35:43', '', 'item-2', '', 'inherit', 'open', 'closed', '', 'item-2-5', '', '', '2017-04-17 02:35:49', '2017-04-16 23:35:49', '', 34, 'http://test2.ru/wp-content/uploads/2017/04/item-2-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(36, 1, '2017-04-17 02:35:55', '2017-04-16 23:35:55', 'Casa Maria Maia is a nonprofit organization in Carapicuiba, São Paulo, dedicated to caring for abandoned children with severe disabilities. A multidisciplinary team of volunteers, including neurologists, physical therapists, social workers, entertainers, and caretakers, tend to 20 children and young adults housed in the facility.', 'Meet Jeni Gonçalves Arruda…', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2017-04-17 02:35:55', '2017-04-16 23:35:55', '', 34, 'http://test2.ru/2017/04/17/34-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2017-04-17 02:44:54', '2017-04-16 23:44:54', 'In partnership with local foundations in the Brazilian states of Espírito Santo, São Paulo, Minas Gerais and Rio de Janeiro, the Da Terra Brasil Foundation distributes wheelchairs to people with disabilities who lack the means and resources to acquire them on their own. Through a careful and selective process, we help ensure mobility and a dignified life for hundreds of Brazilians in need.', 'Brasil is in partnership with local foundations', '', 'publish', 'open', 'open', '', 'brasil-is-in-partnership-with-local-foundations', '', '', '2017-04-17 02:44:54', '2017-04-16 23:44:54', '', 0, 'http://test2.ru/?p=37', 0, 'post', '', 0),
(38, 1, '2017-04-17 02:44:40', '2017-04-16 23:44:40', '', 'item-3', '', 'inherit', 'open', 'closed', '', 'item-3-2', '', '', '2017-04-17 02:44:46', '2017-04-16 23:44:46', '', 37, 'http://test2.ru/wp-content/uploads/2017/04/item-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(39, 1, '2017-04-17 02:44:54', '2017-04-16 23:44:54', 'In partnership with local foundations in the Brazilian states of Espírito Santo, São Paulo, Minas Gerais and Rio de Janeiro, the Da Terra Brasil Foundation distributes wheelchairs to people with disabilities who lack the means and resources to acquire them on their own. Through a careful and selective process, we help ensure mobility and a dignified life for hundreds of Brazilians in need.', 'Brasil is in partnership with local foundations', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2017-04-17 02:44:54', '2017-04-16 23:44:54', '', 37, 'http://test2.ru/2017/04/17/37-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2017-04-17 02:57:30', '2017-04-16 23:57:30', 'Jeni Golcalves Arruda always has a smile on her face, despite her disability and financial struggles.  She has many reasons to be happy. She says her husband, Luis, is the reason for her positive atittute, since he is very supportive of her needs.  Jeni has been confined to a wheelchair since losing her leg to diabetes. When we met Jeni, her chair was old and in disrepair, keeping her inside the house most of the days.', 'Making a Difference at Casa Maria Maia…', '', 'publish', 'open', 'open', '', 'making-a-difference-at-casa-maria-maia', '', '', '2017-04-17 03:14:58', '2017-04-17 00:14:58', '', 0, 'http://test2.ru/?p=40', 0, 'post', '', 0),
(41, 1, '2017-04-17 02:57:30', '2017-04-16 23:57:30', 'Jeni Golcalves Arruda always has a smile on her face, despite her disability and financial struggles.  She has many reasons to be happy. She says her husband, Luis, is the reason for her positive atittute, since he is very supportive of her needs.  Jeni has been confined to a wheelchair since losing her leg to diabetes. When we met Jeni, her chair was old and in disrepair, keeping her inside the house most of the days.', 'Making a Difference at Casa Maria Maia…', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2017-04-17 02:57:30', '2017-04-16 23:57:30', '', 40, 'http://test2.ru/2017/04/17/40-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2017-04-17 03:06:09', '2017-04-17 00:06:09', '', '1', '', 'inherit', 'open', 'closed', '', '1', '', '', '2017-04-17 03:07:41', '2017-04-17 00:07:41', '', 40, 'http://test2.ru/wp-content/uploads/2017/04/1.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2017-04-17 03:22:53', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-04-17 03:22:53', '0000-00-00 00:00:00', '', 0, 'http://test2.ru/?p=43', 0, 'post', '', 0),
(44, 1, '2017-04-17 08:47:27', '2017-04-17 05:47:27', '1“…everyone deserves to live a dignified life, with love and respect…”', 'quote 1', '', 'publish', 'open', 'open', '', 'quote-1', '', '', '2017-04-17 08:52:54', '2017-04-17 05:52:54', '', 0, 'http://test2.ru/?p=44', 0, 'post', '', 0),
(45, 1, '2017-04-17 08:47:27', '2017-04-17 05:47:27', '“…everyone deserves to live a dignified life, with love and respect…”', 'quote 1', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2017-04-17 08:47:27', '2017-04-17 05:47:27', '', 44, 'http://test2.ru/2017/04/17/44-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2017-04-17 08:52:54', '2017-04-17 05:52:54', '1“…everyone deserves to live a dignified life, with love and respect…”', 'quote 1', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2017-04-17 08:52:54', '2017-04-17 05:52:54', '', 44, 'http://test2.ru/2017/04/17/44-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2017-04-17 08:53:38', '2017-04-17 05:53:38', '2“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 2', '', 'publish', 'open', 'open', '', 'quote-2', '', '', '2017-04-17 08:53:38', '2017-04-17 05:53:38', '', 0, 'http://test2.ru/?p=47', 0, 'post', '', 0),
(48, 1, '2017-04-17 08:53:38', '2017-04-17 05:53:38', '2“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 2', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2017-04-17 08:53:38', '2017-04-17 05:53:38', '', 47, 'http://test2.ru/2017/04/17/47-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2017-04-17 08:54:14', '2017-04-17 05:54:14', '3“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 3', '', 'publish', 'open', 'open', '', 'quote-3', '', '', '2017-04-17 08:54:14', '2017-04-17 05:54:14', '', 0, 'http://test2.ru/?p=49', 0, 'post', '', 0),
(50, 1, '2017-04-17 08:54:14', '2017-04-17 05:54:14', '3“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 3', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2017-04-17 08:54:14', '2017-04-17 05:54:14', '', 49, 'http://test2.ru/2017/04/17/49-revision-v1/', 0, 'revision', '', 0),
(51, 1, '2017-04-17 08:54:53', '2017-04-17 05:54:53', '4“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 4', '', 'publish', 'open', 'open', '', 'quote-4', '', '', '2017-04-17 08:54:53', '2017-04-17 05:54:53', '', 0, 'http://test2.ru/?p=51', 0, 'post', '', 0),
(52, 1, '2017-04-17 08:54:53', '2017-04-17 05:54:53', '4“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 4', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2017-04-17 08:54:53', '2017-04-17 05:54:53', '', 51, 'http://test2.ru/2017/04/17/51-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2017-04-17 08:55:22', '2017-04-17 05:55:22', '5“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 5', '', 'publish', 'open', 'open', '', 'quote-5', '', '', '2017-04-17 08:55:22', '2017-04-17 05:55:22', '', 0, 'http://test2.ru/?p=53', 0, 'post', '', 0),
(54, 1, '2017-04-17 08:55:22', '2017-04-17 05:55:22', '5“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 5', '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', '2017-04-17 08:55:22', '2017-04-17 05:55:22', '', 53, 'http://test2.ru/2017/04/17/53-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2017-04-17 08:55:49', '2017-04-17 05:55:49', '6“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 6', '', 'trash', 'open', 'open', '', 'quote-6__trashed', '', '', '2017-04-17 09:14:03', '2017-04-17 06:14:03', '', 0, 'http://test2.ru/?p=55', 0, 'post', '', 0),
(56, 1, '2017-04-17 08:55:49', '2017-04-17 05:55:49', '6“We believe that every human being deserves love, respect, and a chance to live a dignified life.”', 'quote 6', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2017-04-17 08:55:49', '2017-04-17 05:55:49', '', 55, 'http://test2.ru/2017/04/17/55-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2017-04-17 09:47:50', '2017-04-17 06:47:50', 'The Da Terra Brasil Foundation is a nonprofit organization dedicated to supporting and improving the lives of poor and disabled in Brazil. The Foundation focuses on two initiatives: Lar Dos Velhinhos, a facility that provides a safe haven for the elderly, the sick, and the poor in the city of Piranga, and Brasil on Wheels, whose goal is to distribute wheelchairs to the thousands of disabled people across Brazil – many of them homebound – who cannot afford them (<a href="#">click here</a> DaTerraFavv2 to read more).', 'About us', '', 'publish', 'open', 'open', '', 'about-us', '', '', '2017-04-17 09:54:38', '2017-04-17 06:54:38', '', 0, 'http://test2.ru/?p=57', 0, 'post', '', 0),
(58, 1, '2017-04-17 09:47:50', '2017-04-17 06:47:50', 'The Da Terra Brasil Foundation is a nonprofit organization dedicated to supporting and improving the lives of poor and disabled in Brazil. The Foundation focuses on two initiatives: Lar Dos Velhinhos, a facility that provides a safe haven for the elderly, the sick, and the poor in the city of Piranga, and Brasil on Wheels, whose goal is to distribute wheelchairs to the thousands of disabled people across Brazil – many of them homebound – who cannot afford them (<a href="#">click here</a> DaTerraFavv2 to read more).', 'About us', '', 'inherit', 'closed', 'closed', '', '57-revision-v1', '', '', '2017-04-17 09:47:50', '2017-04-17 06:47:50', '', 57, 'http://test2.ru/2017/04/17/57-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2017-04-17 09:52:52', '2017-04-17 06:52:52', '111The Da Terra Brasil Foundation is a nonprofit organization dedicated to supporting and improving the lives of poor and disabled in Brazil. The Foundation focuses on two initiatives: Lar Dos Velhinhos, a facility that provides a safe haven for the elderly, the sick, and the poor in the city of Piranga, and Brasil on Wheels, whose goal is to distribute wheelchairs to the thousands of disabled people across Brazil – many of them homebound – who cannot afford them (<a href="#">click here</a> DaTerraFavv2 to read more).', 'About us', '', 'inherit', 'closed', 'closed', '', '57-revision-v1', '', '', '2017-04-17 09:52:52', '2017-04-17 06:52:52', '', 57, 'http://test2.ru/2017/04/17/57-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2017-04-17 09:54:38', '2017-04-17 06:54:38', 'The Da Terra Brasil Foundation is a nonprofit organization dedicated to supporting and improving the lives of poor and disabled in Brazil. The Foundation focuses on two initiatives: Lar Dos Velhinhos, a facility that provides a safe haven for the elderly, the sick, and the poor in the city of Piranga, and Brasil on Wheels, whose goal is to distribute wheelchairs to the thousands of disabled people across Brazil – many of them homebound – who cannot afford them (<a href="#">click here</a> DaTerraFavv2 to read more).', 'About us', '', 'inherit', 'closed', 'closed', '', '57-revision-v1', '', '', '2017-04-17 09:54:38', '2017-04-17 06:54:38', '', 57, 'http://test2.ru/2017/04/17/57-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2017-04-17 10:02:37', '2017-04-17 07:02:37', 'Maria Inês Moraes was born in Piranga, a small town in the South East of the state of Minas Gerais, Brazil. She moved to Itauna, Minas Gerais, where she attended high school at Colegio Santana. Upon graduating from the University of Itauna, with a degree in Chemistry, Maria moved to New York City, where she met her husband and had two children.\r\n\r\nWith motherhood, Maria discovered a genuine love for young children’s learning and development, as well as deep caring for those less fortunate. After receiving a master’s degree in Early Childhood Education from Bank Street Graduate School, Maria taught preschool children for many years. Maria is now dedicated to the growth of The Da Terra Brasil Foundation and the enriching the lives of the people it serves.', 'Our-team', '', 'publish', 'open', 'open', '', 'our-team', '', '', '2017-04-17 10:02:37', '2017-04-17 07:02:37', '', 0, 'http://test2.ru/?p=61', 0, 'post', '', 0),
(62, 1, '2017-04-17 10:02:25', '2017-04-17 07:02:25', '', 'photo-1', '', 'inherit', 'open', 'closed', '', 'photo-1', '', '', '2017-04-17 10:02:33', '2017-04-17 07:02:33', '', 61, 'http://test2.ru/wp-content/uploads/2017/04/photo-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2017-04-17 10:02:37', '2017-04-17 07:02:37', 'Maria Inês Moraes was born in Piranga, a small town in the South East of the state of Minas Gerais, Brazil. She moved to Itauna, Minas Gerais, where she attended high school at Colegio Santana. Upon graduating from the University of Itauna, with a degree in Chemistry, Maria moved to New York City, where she met her husband and had two children.\r\n\r\nWith motherhood, Maria discovered a genuine love for young children’s learning and development, as well as deep caring for those less fortunate. After receiving a master’s degree in Early Childhood Education from Bank Street Graduate School, Maria taught preschool children for many years. Maria is now dedicated to the growth of The Da Terra Brasil Foundation and the enriching the lives of the people it serves.', 'Our-team', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2017-04-17 10:02:37', '2017-04-17 07:02:37', '', 61, 'http://test2.ru/2017/04/17/61-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2017-04-17 10:24:21', '2017-04-17 07:24:21', 'In partnership with local foundations in the Brazilian states of Espírito Santo, São Paulo, Minas Gerais and Rio de Janeiro, the Da Terra Brasil Foundation distributes wheelchairs to people with disabilities who lack the means and resources to acquire them on their own. Through a careful and selective process, we help ensure mobility and a dignified life for hundreds of Brazilians in need.', 'Brasil on Wheels', '', 'publish', 'open', 'open', '', 'brasil-on-wheels', '', '', '2017-04-17 10:24:21', '2017-04-17 07:24:21', '', 0, 'http://test2.ru/?p=64', 0, 'post', '', 0),
(65, 1, '2017-04-17 10:24:21', '2017-04-17 07:24:21', 'In partnership with local foundations in the Brazilian states of Espírito Santo, São Paulo, Minas Gerais and Rio de Janeiro, the Da Terra Brasil Foundation distributes wheelchairs to people with disabilities who lack the means and resources to acquire them on their own. Through a careful and selective process, we help ensure mobility and a dignified life for hundreds of Brazilians in need.', 'Brasil on Wheels', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2017-04-17 10:24:21', '2017-04-17 07:24:21', '', 64, 'http://test2.ru/2017/04/17/64-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2017-04-17 10:27:38', '2017-04-17 07:27:38', 'Initially built as a home for the elderly community in Piranga, Lar Dos Velhinhos (Home for the Elderly) has become not just a safe haven for the elderly, but also for people of all ages who cannot provide for themselves due to illness or financial difficulties. The Da Terra Brasil Foundation works to improve the Institution’s quality of care and housing conditions. It is our goal to ensure that all residents are given a place of safety, dignity and feeling of belonging', 'Lar Dos Velhinhos', '', 'publish', 'open', 'open', '', 'lar-dos-velhinhos', '', '', '2017-04-17 10:27:38', '2017-04-17 07:27:38', '', 0, 'http://test2.ru/?p=66', 0, 'post', '', 0),
(67, 1, '2017-04-17 10:27:38', '2017-04-17 07:27:38', 'Initially built as a home for the elderly community in Piranga, Lar Dos Velhinhos (Home for the Elderly) has become not just a safe haven for the elderly, but also for people of all ages who cannot provide for themselves due to illness or financial difficulties. The Da Terra Brasil Foundation works to improve the Institution’s quality of care and housing conditions. It is our goal to ensure that all residents are given a place of safety, dignity and feeling of belonging', 'Lar Dos Velhinhos', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2017-04-17 10:27:38', '2017-04-17 07:27:38', '', 66, 'http://test2.ru/2017/04/17/66-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2017-04-17 10:39:34', '2017-04-17 07:39:34', '', 'iGive.com, Donate, Everytime you Shop', '', 'publish', 'open', 'open', '', 'igive-com-donate-everytime-you-shop', '', '', '2017-04-17 10:39:34', '2017-04-17 07:39:34', '', 0, 'http://test2.ru/?p=68', 0, 'post', '', 0),
(69, 1, '2017-04-17 10:38:58', '2017-04-17 07:38:58', '', 'item-1', '', 'inherit', 'open', 'closed', '', 'item-1-5', '', '', '2017-04-17 10:42:50', '2017-04-17 07:42:50', '', 68, 'http://test2.ru/wp-content/uploads/2017/04/item-1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(70, 1, '2017-04-17 10:39:01', '2017-04-17 07:39:01', '', 'item-2', '', 'inherit', 'open', 'closed', '', 'item-2-6', '', '', '2017-04-17 10:42:19', '2017-04-17 07:42:19', '', 68, 'http://test2.ru/wp-content/uploads/2017/04/item-2-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(71, 1, '2017-04-17 10:39:04', '2017-04-17 07:39:04', '', 'item-3', '', 'inherit', 'open', 'closed', '', 'item-3-3', '', '', '2017-04-17 10:41:28', '2017-04-17 07:41:28', '', 68, 'http://test2.ru/wp-content/uploads/2017/04/item-3-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2017-04-17 10:39:06', '2017-04-17 07:39:06', '', 'item-4', '', 'inherit', 'open', 'closed', '', 'item-4', '', '', '2017-04-17 10:40:42', '2017-04-17 07:40:42', '', 68, 'http://test2.ru/wp-content/uploads/2017/04/item-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(73, 1, '2017-04-17 10:39:09', '2017-04-17 07:39:09', '', 'item-5', '', 'inherit', 'open', 'closed', '', 'item-5', '', '', '2017-04-17 10:39:09', '2017-04-17 07:39:09', '', 68, 'http://test2.ru/wp-content/uploads/2017/04/item-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2017-04-17 10:39:11', '2017-04-17 07:39:11', '', 'item-6', '', 'inherit', 'open', 'closed', '', 'item-6', '', '', '2017-04-17 10:39:28', '2017-04-17 07:39:28', '', 68, 'http://test2.ru/wp-content/uploads/2017/04/item-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2017-04-17 10:39:34', '2017-04-17 07:39:34', '', 'iGive.com, Donate, Everytime you Shop', '', 'inherit', 'closed', 'closed', '', '68-revision-v1', '', '', '2017-04-17 10:39:34', '2017-04-17 07:39:34', '', 68, 'http://test2.ru/2017/04/17/68-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2017-04-17 10:40:10', '2017-04-17 07:40:10', '', 'Make a Donation & shop @AmazonSmile', '', 'publish', 'open', 'open', '', 'make-a-donation-shop-amazonsmile', '', '', '2017-04-17 10:41:45', '2017-04-17 07:41:45', '', 0, 'http://test2.ru/?p=76', 0, 'post', '', 0),
(77, 1, '2017-04-17 10:40:10', '2017-04-17 07:40:10', '', 'Make a Donation & shop @AmazonSmile', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2017-04-17 10:40:10', '2017-04-17 07:40:10', '', 76, 'http://test2.ru/2017/04/17/76-revision-v1/', 0, 'revision', '', 0),
(78, 1, '2017-04-17 10:40:19', '2017-04-17 07:40:19', '', 'Make a Donation & shop @AmazonSmile', '', 'inherit', 'closed', 'closed', '', '76-autosave-v1', '', '', '2017-04-17 10:40:19', '2017-04-17 07:40:19', '', 76, 'http://test2.ru/2017/04/17/76-autosave-v1/', 0, 'revision', '', 0),
(79, 1, '2017-04-17 10:40:50', '2017-04-17 07:40:50', '', 'Birthdays for Wheels', '', 'publish', 'open', 'open', '', 'birthdays-for-wheels', '', '', '2017-04-17 10:40:50', '2017-04-17 07:40:50', '', 0, 'http://test2.ru/?p=79', 0, 'post', '', 0),
(80, 1, '2017-04-17 10:40:50', '2017-04-17 07:40:50', '', 'Birthdays for Wheels', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2017-04-17 10:40:50', '2017-04-17 07:40:50', '', 79, 'http://test2.ru/2017/04/17/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2017-04-17 10:41:31', '2017-04-17 07:41:31', '', 'Become a Friend', '', 'publish', 'open', 'open', '', 'become-a-friend', '', '', '2017-04-17 10:41:31', '2017-04-17 07:41:31', '', 0, 'http://test2.ru/?p=81', 0, 'post', '', 0),
(82, 1, '2017-04-17 10:41:31', '2017-04-17 07:41:31', '', 'Become a Friend', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2017-04-17 10:41:31', '2017-04-17 07:41:31', '', 81, 'http://test2.ru/2017/04/17/81-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2017-04-17 10:42:25', '2017-04-17 07:42:25', '', 'Become a Volunteer', '', 'publish', 'open', 'open', '', 'become-a-volunteer', '', '', '2017-04-17 10:42:25', '2017-04-17 07:42:25', '', 0, 'http://test2.ru/?p=83', 0, 'post', '', 0),
(84, 1, '2017-04-17 10:42:25', '2017-04-17 07:42:25', '', 'Become a Volunteer', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2017-04-17 10:42:25', '2017-04-17 07:42:25', '', 83, 'http://test2.ru/2017/04/17/83-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2017-04-17 10:42:55', '2017-04-17 07:42:55', '', 'Make a Donation', '', 'publish', 'open', 'open', '', 'make-a-donation', '', '', '2017-04-17 10:42:55', '2017-04-17 07:42:55', '', 0, 'http://test2.ru/?p=85', 0, 'post', '', 0),
(86, 1, '2017-04-17 10:42:55', '2017-04-17 07:42:55', '', 'Make a Donation', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2017-04-17 10:42:55', '2017-04-17 07:42:55', '', 85, 'http://test2.ru/2017/04/17/85-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2017-04-17 10:54:42', '2017-04-17 07:54:42', 'A big thank you to the Brazilian-American Chamber of Commerce in New York City for promoting the Portal Amigo do Idoso Cocktail Reception on their website. To read the whole article follow the link below:\r\n\r\n<a class="news-item__txt-lk" href="http://brazilcham.com/featured-industry-events">http://brazilcham.com/featured-industry-events</a>', 'The Portal Amigo do Idoso event on behalf of the Brasil on Wheels campaign, appears on the Brazilian-American Chamber of Commerce website', '', 'trash', 'open', 'open', '', 'the-portal-amigo-do-idoso-event-on-behalf-of-the-brasil-on-wheels-campaign-appears-on-the-brazilian-american-chamber-of-commerce-website__trashed', '', '', '2017-04-17 11:03:00', '2017-04-17 08:03:00', '', 0, 'http://test2.ru/?p=87', 0, 'post', '', 0),
(88, 1, '2017-04-17 10:54:42', '2017-04-17 07:54:42', 'A big thank you to the Brazilian-American Chamber of Commerce in New York City for promoting the Portal Amigo do Idoso Cocktail Reception on their website. To read the whole article follow the link below:\r\n\r\n<a class="news-item__txt-lk" href="http://brazilcham.com/featured-industry-events">http://brazilcham.com/featured-industry-events</a>', 'The Portal Amigo do Idoso event on behalf of the Brasil on Wheels campaign, appears on the Brazilian-American Chamber of Commerce website', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-04-17 10:54:42', '2017-04-17 07:54:42', '', 87, 'http://test2.ru/2017/04/17/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2017-04-17 10:56:35', '2017-04-17 07:56:35', 'Super agradecida ao journalista pela entrevista e pelo interesse a nossa causa. Por favor, acess o link abaixo para que leia toda a entrevista. Juntos por uma causa! Maria Inês Moraes\r\n\r\n<a class="news-item__txt-lk" href="http://www.braziliantimes.com/impresso/1486 — p.8">http://www.braziliantimes.com/impresso/1486 — p.8</a>', 'Da Terra Brasil Foundation Founder is interviewed by journalist George Roberts!', '', 'publish', 'open', 'open', '', 'da-terra-brasil-foundation-founder-is-interviewed-by-journalist-george-roberts', '', '', '2017-04-17 10:56:35', '2017-04-17 07:56:35', '', 0, 'http://test2.ru/?p=89', 0, 'post', '', 0),
(90, 1, '2017-04-17 10:56:35', '2017-04-17 07:56:35', 'Super agradecida ao journalista pela entrevista e pelo interesse a nossa causa. Por favor, acess o link abaixo para que leia toda a entrevista. Juntos por uma causa! Maria Inês Moraes\r\n\r\n<a class="news-item__txt-lk" href="http://www.braziliantimes.com/impresso/1486 — p.8">http://www.braziliantimes.com/impresso/1486 — p.8</a>', 'Da Terra Brasil Foundation Founder is interviewed by journalist George Roberts!', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2017-04-17 10:56:35', '2017-04-17 07:56:35', '', 89, 'http://test2.ru/2017/04/17/89-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2017-04-17 11:03:47', '2017-04-17 08:03:47', 'A big thank you to the Brazilian-American Chamber of Commerce in New York City for promoting the Portal Amigo do Idoso Cocktail Reception on their website. To read the whole article follow the link below:\r\n\r\n<a class="news-item__txt-lk" href="http://brazilcham.com/featured-industry-events">http://brazilcham.com/featured-industry-events</a>', 'The Portal Amigo do Idoso event on behalf of the Brasil on Wheels campaign, appears on the Brazilian-American Chamber of Commerce website', '', 'publish', 'open', 'open', '', 'the-portal-amigo-do-idoso-event-on-behalf-of-the-brasil-on-wheels-campaign-appears-on-the-brazilian-american-chamber-of-commerce-website', '', '', '2017-04-17 11:03:47', '2017-04-17 08:03:47', '', 0, 'http://test2.ru/?p=91', 0, 'post', '', 0),
(92, 1, '2017-04-17 11:03:47', '2017-04-17 08:03:47', 'A big thank you to the Brazilian-American Chamber of Commerce in New York City for promoting the Portal Amigo do Idoso Cocktail Reception on their website. To read the whole article follow the link below:\r\n\r\n<a class="news-item__txt-lk" href="http://brazilcham.com/featured-industry-events">http://brazilcham.com/featured-industry-events</a>', 'The Portal Amigo do Idoso event on behalf of the Brasil on Wheels campaign, appears on the Brazilian-American Chamber of Commerce website', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2017-04-17 11:03:47', '2017-04-17 08:03:47', '', 91, 'http://test2.ru/2017/04/17/91-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2017-04-17 11:16:15', '2017-04-17 08:16:15', '[contact-form-7 id="95" title="contact form 1"]', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2017-04-17 11:16:15', '2017-04-17 08:16:15', '', 0, 'http://test2.ru/?p=93', 0, 'post', '', 0),
(95, 1, '2017-04-17 11:15:38', '2017-04-17 08:15:38', '<span class=''contact-form__radio-txt''>Questions about:</span>[radio radio-60 class:asas default:1 "Volunteering" "Inquire about donations" "More information" "Other"]\r\n[text* text-128 placeholder "Name (required)"] [email email-807 placeholder "E-mail Address (required)"]\r\n[textarea textarea-718 placeholder "Message"]\r\n\r\n[submit "submit"]\n1\nDa Terra Brasil Foundation "[your-subject]"\n[your-name] <wordpress@test2.ru>\nadmin@admin.ru\nОт: [your-name] <[your-email]>\r\nТема: [your-subject]\r\n\r\nСообщение:\r\n[your-message]\r\n\r\n-- \r\nЭто сообщение отправлено с сайта Da Terra Brasil Foundation (http://test2.ru)\nReply-To: [your-email]\n\n\n\n\nDa Terra Brasil Foundation "[your-subject]"\nDa Terra Brasil Foundation <wordpress@test2.ru>\n[your-email]\nСообщение:\r\n[your-message]\r\n\r\n-- \r\nЭто сообщение отправлено с сайта Da Terra Brasil Foundation (http://test2.ru)\nReply-To: admin@admin.ru\n\n\n\nСпасибо за Ваше сообщение. Оно успешно отправлено.\nПри отправке сообщения произошла ошибка. Пожалуйста, попробуйте ещё раз позже.\nОдно или несколько полей содержат ошибочные данные. Пожалуйста, проверьте их и попробуйте ещё раз.\nПри отправке сообщения произошла ошибка. Пожалуйста, попробуйте ещё раз позже.\nВы должны принять условия и положения перед отправкой вашего сообщения.\nПоле обязательно для заполнения.\nПоле слишком длинное.\nПоле слишком короткое.\nФормат даты некорректен.\nВведённая дата слишком далеко в прошлом.\nВведённая дата слишком далеко в будущем.\nПри загрузке файла произошла неизвестная ошибка.\nВам не разрешено загружать файлы этого типа.\nФайл слишком большой.\nПри загрузке файла произошла ошибка.\nФормат числа некорректен.\nЧисло меньше минимально допустимого.\nЧисло больше максимально допустимого.\nНеверный ответ на проверочный вопрос.\nКод введен неверно.\nНеверно введён электронный адрес.\nВведён некорректный URL адрес.\nВведён некорректный телефонный номер.', 'contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2017-04-17 12:31:35', '2017-04-17 09:31:35', '', 0, 'http://test2.ru/?post_type=wpcf7_contact_form&#038;p=95', 0, 'wpcf7_contact_form', '', 0),
(96, 1, '2017-04-17 11:16:15', '2017-04-17 08:16:15', '[contact-form-7 id="95" title="contact form 1"]', 'Contact form 1', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2017-04-17 11:16:15', '2017-04-17 08:16:15', '', 93, 'http://test2.ru/2017/04/17/93-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2017-04-17 13:12:30', '2017-04-17 10:12:30', 'Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:\n\n<blockquote>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</blockquote>\n\n...или так:\n\n<blockquote>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</blockquote>\n\nПерейдите <a href="http://test2.ru/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!', 'Home page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-17 13:12:30', '2017-04-17 10:12:30', '', 2, 'http://test2.ru/2017/04/17/2-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2017-04-17 13:41:55', '2017-04-17 10:41:55', '', 'Page-events', '', 'publish', 'closed', 'closed', '', 'page-events', '', '', '2017-04-22 19:36:39', '2017-04-22 16:36:39', '', 0, 'http://test2.ru/?page_id=98', 0, 'page', '', 0),
(99, 1, '2017-04-17 13:41:55', '2017-04-17 10:41:55', '', 'Events-page', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-04-17 13:41:55', '2017-04-17 10:41:55', '', 98, 'http://test2.ru/2017/04/17/98-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2017-04-17 13:42:32', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-04-17 13:42:32', '0000-00-00 00:00:00', '', 0, 'http://test2.ru/?p=100', 1, 'nav_menu_item', '', 0),
(101, 1, '2017-04-17 14:14:53', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2017-04-17 14:14:53', '0000-00-00 00:00:00', '', 0, 'http://test2.ru/?post_type=movie_reviews&p=101', 0, 'movie_reviews', '', 0),
(102, 1, '2017-04-17 14:27:49', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2017-04-17 14:27:49', '0000-00-00 00:00:00', '', 0, 'http://test2.ru/?post_type=movie_reviews&p=102', 0, 'movie_reviews', '', 0),
(103, 1, '2017-04-17 14:30:53', '2017-04-17 11:30:53', 'New event description', 'Event 1', '', 'publish', 'open', 'closed', '', 'event-1', '', '', '2017-04-17 14:30:53', '2017-04-17 11:30:53', '', 0, 'http://test2.ru/?post_type=movie_reviews&#038;p=103', 0, 'movie_reviews', '', 0),
(104, 1, '2017-04-17 15:17:34', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2017-04-17 15:17:34', '0000-00-00 00:00:00', '', 0, 'http://test2.ru/?post_type=events&p=104', 0, 'events', '', 0),
(105, 1, '2017-04-17 15:27:05', '2017-04-17 12:27:05', 'Event description', 'Event 1', '', 'publish', 'open', 'closed', '', 'event-1', '', '', '2017-04-17 16:30:18', '2017-04-17 13:30:18', '', 0, 'http://test2.ru/?post_type=events&#038;p=105', 0, 'events', '', 0),
(106, 1, '2017-04-17 15:53:25', '2017-04-17 12:53:25', '', 'Home page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-17 15:53:25', '2017-04-17 12:53:25', '', 2, 'http://test2.ru/2017/04/17/2-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2017-04-17 15:54:10', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-04-17 15:54:10', '0000-00-00 00:00:00', '', 0, 'http://test2.ru/?page_id=107', 0, 'page', '', 0),
(108, 1, '2017-04-17 16:08:30', '2017-04-17 13:08:30', 'Event 2 text description', 'Event 2', '', 'publish', 'open', 'closed', '', 'event-2', '', '', '2017-04-17 16:31:34', '2017-04-17 13:31:34', '', 0, 'http://test2.ru/?post_type=events&#038;p=108', 0, 'events', '', 0),
(109, 1, '2017-04-17 16:11:12', '2017-04-17 13:11:12', 'Hello World', 'Events-page', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-04-17 16:11:12', '2017-04-17 13:11:12', '', 98, 'http://test2.ru/2017/04/17/98-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2017-04-17 16:12:40', '2017-04-17 13:12:40', 'Event 3 description', 'Event 3', '', 'publish', 'open', 'closed', '', 'event-3', '', '', '2017-04-17 16:32:13', '2017-04-17 13:32:13', '', 0, 'http://test2.ru/?post_type=events&#038;p=110', 0, 'events', '', 0),
(111, 1, '2017-04-17 16:14:43', '2017-04-17 13:14:43', '', 'Events-page', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-04-17 16:14:43', '2017-04-17 13:14:43', '', 98, 'http://test2.ru/2017/04/17/98-revision-v1/', 0, 'revision', '', 0),
(113, 1, '2017-04-17 16:49:54', '2017-04-17 13:49:54', 'Text for event 4', 'Event 4', '', 'publish', 'open', 'closed', '', 'event-4', '', '', '2017-04-17 16:50:42', '2017-04-17 13:50:42', '', 0, 'http://test2.ru/?post_type=events&#038;p=113', 0, 'events', '', 0),
(114, 1, '2017-04-22 17:49:51', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2017-04-22 17:49:51', '0000-00-00 00:00:00', '', 0, 'http://test2.ru/?post_type=events&p=114', 0, 'events', '', 0),
(115, 1, '2017-04-22 18:52:26', '2017-04-22 15:52:26', '', 'Page-events', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-04-22 18:52:26', '2017-04-22 15:52:26', '', 98, 'http://test2.ru/2017/04/22/98-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreetermmeta`
--

CREATE TABLE IF NOT EXISTS `wp_singreetermmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreeterms`
--

CREATE TABLE IF NOT EXISTS `wp_singreeterms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `wp_singreeterms`
--

INSERT INTO `wp_singreeterms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'Main menu', 'main-menu', 0),
(3, 'Secondary menu', 'secondary-menu', 0),
(4, 'stories', 'stories', 0),
(5, 'quotes', 'quotes', 0),
(6, 'about-us', 'about-us', 0),
(7, 'our-team', 'our-team', 0),
(8, 'Our-work', 'our-work', 0),
(9, 'ways', 'ways', 0),
(10, 'news', 'news', 0),
(11, 'contact', 'contact', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreeterm_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_singreeterm_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_singreeterm_relationships`
--

INSERT INTO `wp_singreeterm_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(11, 2, 0),
(12, 2, 0),
(13, 2, 0),
(14, 2, 0),
(15, 2, 0),
(16, 3, 0),
(17, 3, 0),
(18, 3, 0),
(19, 3, 0),
(20, 3, 0),
(21, 3, 0),
(22, 3, 0),
(23, 3, 0),
(24, 3, 0),
(25, 3, 0),
(26, 4, 0),
(30, 4, 0),
(34, 4, 0),
(37, 4, 0),
(40, 4, 0),
(44, 5, 0),
(47, 5, 0),
(49, 5, 0),
(51, 5, 0),
(53, 5, 0),
(55, 5, 0),
(57, 6, 0),
(61, 7, 0),
(64, 8, 0),
(66, 8, 0),
(68, 9, 0),
(76, 9, 0),
(79, 9, 0),
(81, 9, 0),
(83, 9, 0),
(85, 9, 0),
(87, 10, 0),
(89, 10, 0),
(91, 10, 0),
(93, 11, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreeterm_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_singreeterm_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `wp_singreeterm_taxonomy`
--

INSERT INTO `wp_singreeterm_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 5),
(3, 3, 'nav_menu', '', 0, 10),
(4, 4, 'category', '', 0, 5),
(5, 5, 'category', '', 0, 5),
(6, 6, 'category', '', 0, 1),
(7, 7, 'category', '', 0, 1),
(8, 8, 'category', '', 0, 2),
(9, 9, 'category', '', 0, 6),
(10, 10, 'category', '', 0, 2),
(11, 11, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreeusermeta`
--

CREATE TABLE IF NOT EXISTS `wp_singreeusermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Дамп данных таблицы `wp_singreeusermeta`
--

INSERT INTO `wp_singreeusermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_singreecapabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_singreeuser_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '0'),
(15, 1, 'session_tokens', 'a:5:{s:64:"9aac7861b393d649b2933eacef65f493670acdecd0311b8bbdf43657de73beac";a:4:{s:10:"expiration";i:1493579203;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36";s:5:"login";i:1492369603;}s:64:"23863ae127111573fa950b84c7004ebb8767174034e2544f9e757972001e40c0";a:4:{s:10:"expiration";i:1493595559;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36";s:5:"login";i:1492385959;}s:64:"af9136eb01c9248185f85430614379ee804b1add390f97e7787f2eeb19b7a555";a:4:{s:10:"expiration";i:1493596685;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36";s:5:"login";i:1492387085;}s:64:"3cb42402e084852fa0027fce5665702636ff0cbdc2ea183afc3ba654f04e8241";a:4:{s:10:"expiration";i:1493597588;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36";s:5:"login";i:1492387988;}s:64:"393b8e6d593319d35402311c259e0c38278fe21e594d2d3a55709e10f66795dd";a:4:{s:10:"expiration";i:1493045343;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36";s:5:"login";i:1492872543;}}'),
(16, 1, 'wp_singreedashboard_quick_press_last_post_id', '3'),
(17, 1, 'wp_singreeuser-settings', 'libraryContent=browse&editor=tinymce'),
(18, 1, 'wp_singreeuser-settings-time', '1492412556'),
(19, 1, 'closedpostboxes_post', 'a:3:{i:0;s:9:"formatdiv";i:1;s:11:"categorydiv";i:2;s:16:"tagsdiv-post_tag";}'),
(20, 1, 'metaboxhidden_post', 'a:6:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}'),
(21, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(23, 1, 'nav_menu_recently_edited', '3'),
(24, 1, 'closedpostboxes_movie_reviews', 'a:0:{}'),
(25, 1, 'metaboxhidden_movie_reviews', 'a:1:{i:0;s:7:"slugdiv";}'),
(26, 1, 'closedpostboxes_page', 'a:0:{}'),
(27, 1, 'metaboxhidden_page', 'a:5:{i:0;s:10:"postcustom";i:1;s:16:"commentstatusdiv";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'),
(28, 1, 'closedpostboxes_events', 'a:0:{}'),
(29, 1, 'metaboxhidden_events', 'a:1:{i:0;s:7:"slugdiv";}');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_singreeusers`
--

CREATE TABLE IF NOT EXISTS `wp_singreeusers` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `wp_singreeusers`
--

INSERT INTO `wp_singreeusers` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BTQb7459/R1VZckJq2RW8asPBY8w.21', 'admin', 'admin@admin.ru', '', '2017-04-16 19:06:38', '', 0, 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
